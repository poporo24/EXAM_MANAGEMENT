"""
================================================================================
CCA EXAM MANAGEMENT SYSTEM - PRIMARY APPLICATION SERVER & ROUTE CONTROLLER
================================================================================
File: app.py
Institution: City College of Angeles (CCA)
System: Automated Academic Examination Scheduling & Administration Platform

Description:
  Acts as the primary Flask application controller orchestrating:
  - Role-based routing (Super Admin, Admin, Secretary, Faculty/Proctor, Student)
  - Integration with the automated timetable Constraint Satisfaction Problem engine
  - Examination resource administration (rooms, subjects, faculty, exam requests)
  - Examination material handouts and custody returns tracking
  - Proctor availability declaration and relief assignment workflows
  - Automated PDF/CSV reports, examination passes, and timetable generation
  - Cryptographic authentication, session security, CSRF protection, and audit logging
================================================================================
"""
from flask import (Flask, render_template, session, redirect, url_for,
                   request, flash, jsonify, send_file, make_response)
from flask_mail import Mail, Message as MailMessage
from datetime import date, datetime, timedelta
from collections import defaultdict
import io, os, time, threading
os.environ['TZ'] = 'Asia/Manila'
if hasattr(time, 'tzset'):
    try:
        time.tzset()
    except Exception:
        pass

import secrets
from datetime import datetime, timedelta
from system.mailer import send_reset_email
from system.database import (
    set_password_reset_token, get_user_by_reset_token, get_user_by_email, clear_reset_token_and_update_password,
    # settings
    get_system_settings, save_system_settings,
    # institutes
    get_all_institutes, add_institute, edit_institute, delete_institute,
    # subjects
    get_all_subjects, get_subjects_by_institute, add_subject, edit_subject,
    delete_subject, link_subjects_content_group, unlink_subject_content_group, check_subjects_section_overlap,
    get_common_subjects,
    get_subject_content_groups, bulk_import_subjects,
    # users
    register_user, get_all_users, get_user_by_id, update_user, delete_user,
    bulk_delete_users_and_proctors,
    get_all_students, get_pending_users, approve_student, get_pending_registration_signature,
    deactivate_student, bulk_deactivate_students, bulk_delete_students,
    # rooms
    get_all_rooms, get_rooms_by_institute, get_all_buildings, get_buildings_summary, delete_custom_building, add_room, edit_room, delete_room,
    bulk_import_rooms,
    # instructors / faculty
    get_all_instructors, get_active_instructors, get_instructor_by_id,
    add_instructor, edit_instructor, deactivate_instructor, activate_instructor,
    delete_instructor, bulk_import_instructors,
    get_proctor_total_hours, get_all_proctor_hours_summary,
    # exams
    get_dashboard_stats, get_upcoming_exams, add_exam, edit_exam_details,
    delete_exam, delete_all_exams, get_pending_exams, get_all_exams, get_exam_by_id,
    get_student_exam_load_per_day, bulk_import_exams, bulk_delete_exams,
    # scheduling
    get_already_scheduled_slots, apply_schedule_results, reset_schedule, unschedule_exams,
    sync_exam_and_subject_institutes,
    get_schedule_results, check_edit_conflicts, apply_exam_edit, get_available_resources,
    save_exam_period, save_exam_term, get_exam_term, get_exam_period,
    create_schedule_reset_request, get_pending_schedule_reset_request,
    get_all_schedule_reset_requests, approve_schedule_reset_request, reject_schedule_reset_request,
    # proctor availability
    get_proctor_availability, get_proctor_availability_for, save_proctor_availability,
    bulk_save_proctor_availability,
    get_proctor_exams,
    # timetable
    get_public_timetable, is_schedule_published, publish_schedule, unpublish_schedule, get_all_sections,
    # relievers
    add_reliever, get_relievers_for_exam, get_all_relievers, remove_reliever,
    # secretary
    get_exam_collection_status, mark_exam_collected, mark_exam_returned,
    get_collection_stats,
    # absence
    record_proctor_absence, get_proctor_absence_report, get_absence_stats, clear_absence_reports,
    # notifications
    create_notification, get_notifications, get_unread_count, clear_all_notifications,
    delete_selected_notifications,
    mark_notification_read, mark_all_read, create_notification_for_role, get_live_sync_signature,
    # reports
    get_scheduling_report, get_assignment_report, get_student_exam_load_report,
    # archives
    create_exam_archive, get_exam_archives, get_exam_archive_by_id, delete_exam_archive, sync_archive_durations,
    # period & audit
    open_db, ensure_database_schema, log_audit_event,
)
from system.scheduler import run_scheduler
from system.logic import verify_login, is_super_admin, hash_password, validate_password_strength
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_limiter.errors import RateLimitExceeded

# ==============================================================================
# SECTION 01: FLASK APPLICATION & SECURITY CONFIGURATION
# ==============================================================================


app = Flask(__name__, template_folder='template')
from werkzeug.middleware.proxy_fix import ProxyFix
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
from flask_wtf.csrf import CSRFProtect, generate_csrf, CSRFError
csrf = CSRFProtect(app)

limiter = Limiter(
    key_func=get_remote_address,
    app=app,
    default_limits=["2500 per day", "600 per hour"],
    storage_uri="memory://"
)

app.secret_key = os.environ.get("FLASK_SECRET_KEY", "cca_exam_management_secret_key_v2")
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    MAX_CONTENT_LENGTH=16 * 1024 * 1024,  # 16 MB max upload limit
    WTF_CSRF_TIME_LIMIT=7200,  # 2 hours CSRF token validity
    PERMANENT_SESSION_LIFETIME=timedelta(minutes=20)
)

@app.before_request
def check_session_inactivity():
    """
    PURPOSE: Automatically logs out users after 20 minutes of inactivity and audits the timeout event.
    ACCESS:  Session middleware (all authenticated users)
    METHOD:  Flask before_request hook
    """
    # Skip idle check for static resources and public login/register/reset endpoints
    # 'api_unread_count' is skipped so background polling does NOT refresh _last_active
    # (otherwise idle users would never be auto-logged out). It enforces the idle check itself.
    if request.path.startswith('/static/') or request.endpoint in ('static', 'public_timetable', 'login', 'register_page', 'register_submit', 'forgot_password', 'reset_password', 'api_unread_count'):
        return None

    if 'user_id' in session:
        import time as _time
        now = _time.time()
        last_active = session.get('_last_active')
        # Auto-logout after 20 minutes of inactivity (1200 seconds)
        if last_active and (now - float(last_active) > 1200):
            uid = session.get('user_id')
            uname = session.get('full_name')
            role = session.get('role')
            session.clear()
            log_audit_event('AUTH_SESSION_TIMEOUT', f"Session auto-terminated due to 20-minute inactivity for user {uname}", user_id=uid, user_name=uname, user_role=role, ip_address=request.remote_addr)
            flash("Your session has expired due to 20 minutes of inactivity. Please log in again.", "warning")
            return redirect(url_for('login'))
        session['_last_active'] = now
    return None

# Automatically ensure database schema (tables & columns) exists
try:
    ensure_database_schema()
except Exception as _schema_err:
    print(f"Warning: automatic database schema check encountered an error: {_schema_err}")

# ==============================================================================
# SECTION 02: EMAIL DISPATCH & NOTIFICATION SERVICE
# ==============================================================================

def _configure_mail():
    """
    PURPOSE: Dynamically configures SMTP and mail settings from environment variables or database.
    ACCESS:  Internal system helper
    """
    try:
        s = get_system_settings()
    except Exception:
        s = {}
    # Prioritize secure environment variables over database storage
    app.config['MAIL_SERVER']         = os.environ.get('SMTP_HOST') or s.get('smtp_host', '') or ''
    app.config['MAIL_PORT']           = int(os.environ.get('SMTP_PORT') or s.get('smtp_port') or 587)
    app.config['MAIL_USERNAME']       = os.environ.get('SMTP_USER') or s.get('smtp_user', '') or ''
    app.config['MAIL_PASSWORD']       = (os.environ.get('SMTP_PASSWORD') or s.get('smtp_password', '') or '').replace(' ', '').strip()
    app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('SMTP_FROM') or s.get('smtp_from', '') or ''
    app.config['MAIL_USE_TLS']        = bool(int(os.environ.get('SMTP_USE_TLS', s.get('smtp_use_tls', 1))))
    app.config['MAIL_USE_SSL']        = False
    app.config['MAIL_TIMEOUT']        = 5
    app.config['MAIL_SUPPRESS_SEND']  = not bool(app.config['MAIL_SERVER'])
    
    # Re-initialize the Mail extension to pick up these new config values immediately
    if hasattr(app, 'extensions') and 'mail' in app.extensions:
        mail.init_app(app)

_configure_mail()
mail = Mail(app)
from concurrent.futures import ThreadPoolExecutor
_MAIL_POOL = ThreadPoolExecutor(max_workers=2)

import time as _time_mod
_RECENT_EMAIL_CACHE = {}  # (to_email_lower, subject_lower) -> timestamp
_EMAIL_CACHE_LOCK = threading.Lock()
_PUBLISH_EMAIL_LOCK = threading.Lock()
_PUBLISH_IN_PROGRESS = False

def _can_send_email(to_email, subject, cooldown_seconds=600):
    """
    PURPOSE: Anti-spam guard preventing duplicate automated emails to the same recipient within a cooldown window.
    ACCESS:  Internal mail helper
    """
    if not to_email:
        return False
    key = (to_email.strip().lower(), (subject or '').strip().lower())
    now = _time_mod.time()
    with _EMAIL_CACHE_LOCK:
        last = _RECENT_EMAIL_CACHE.get(key)
        if last and (now - last) < cooldown_seconds:
            print(f"[Anti-Spam Suppressed] Duplicate email to {to_email} ('{subject}') within {cooldown_seconds}s cooldown.")
            return False
        _RECENT_EMAIL_CACHE[key] = now
        # Periodic cleanup of old entries
        if len(_RECENT_EMAIL_CACHE) > 1000:
            for k in list(_RECENT_EMAIL_CACHE.keys()):
                if now - _RECENT_EMAIL_CACHE[k] > 3600:
                    del _RECENT_EMAIL_CACHE[k]
        return True


def send_email_notification(to_email, subject, body, bypass_cooldown=False):
    """
    PURPOSE: Dispatches an asynchronous email notification in a background thread via Brevo API or Flask-Mail.
    ACCESS:  Internal mail dispatcher
    """
    if not bypass_cooldown and not _can_send_email(to_email, subject):
        return
    try:
        s = get_system_settings()
        brevo_key = os.environ.get('BREVO_API_KEY') or s.get('brevo_api_key')
        smtp_pw = (s.get('smtp_password') or '').replace(' ', '').strip()
        if not brevo_key and smtp_pw.startswith('xkeysib-'):
            brevo_key = smtp_pw

        if brevo_key:
            sender_email = s.get('smtp_from') or s.get('smtp_user') or 'jpbaltazar23-0368@cca.edu.ph'
            from system.mailer import send_via_brevo
            def _send_brevo():
                send_via_brevo(brevo_key, to_email, subject, body, sender_email=sender_email)
            _MAIL_POOL.submit(_send_brevo)
            return
    except Exception as e:
        print(f"[Mail Setting Check Error] {e}")

    if not app.config.get('MAIL_SERVER'):
        return
    def _send():
        try:
            with app.app_context():
                msg = MailMessage(subject=subject, recipients=[to_email], body=body)
                mail.send(msg)
        except Exception as e:
            print(f"[Mail Error] {e}")
    _MAIL_POOL.submit(_send)

# ==============================================================================
# SECTION 03: SECURITY GUARDS, TEMPLATE FILTERS & HELPERS
# ==============================================================================

def require_login():
    """
    PURPOSE: Route guard enforcing that an active authenticated session exists.
    ACCESS:  Internal authentication guard
    RETURNS: Redirect to login page if unauthenticated, None otherwise
    """
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return None

def require_super_admin():
    """
    PURPOSE: Route guard enforcing that the active session holds Super Admin privileges.
    ACCESS:  Super Admin gate
    RETURNS: Redirect if unauthorized, None otherwise
    """
    guard = require_login()
    if guard:
        return guard
    if not session.get('is_super_admin'):
        flash("Access denied. Super Admin privileges required.", "danger")
        return _redirect_by_role()
    return None

@app.after_request
def add_security_and_cache_headers(response):
    """
    PURPOSE: Injects HTTP security headers (X-Frame-Options, X-Content-Type-Options, Cache-Control, auto CSRF meta tags).
    ACCESS:  HTTP response middleware
    METHOD:  Flask after_request hook
    """
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    # Security Headers (Addresses MED-03 Clickjacking & MIME-Sniffing)
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    
    # Auto-inject CSRF meta tag and auto-protection script into HTML responses
    if response.mimetype == 'text/html' and response.status_code == 200:
        html = response.get_data(as_text=True)
        if '</head>' in html and 'csrf.js' not in html:
            token = generate_csrf()
            csrf_tags = (
                f'<meta name="csrf-token" content="{token}">\n'
                f'<script src="/static/js/csrf.js"></script>\n'
            )
            response.set_data(html.replace('</head>', f'{csrf_tags}</head>', 1))
    return response

@app.errorhandler(CSRFError)
def handle_csrf_error(e):
    """
    PURPOSE: Gracefully intercepts missing or invalid CSRF tokens and returns user-friendly warning or JSON 400.
    ACCESS:  Error handler
    """
    if request.is_json or request.path.startswith('/api/'):
        return jsonify({'error': 'CSRF token missing or invalid', 'message': str(e.description)}), 400
    flash(f"Security notice: {e.description}. Please refresh the page and try again.", "warning")
    return redirect(request.referrer or url_for('login'))

@app.errorhandler(RateLimitExceeded)
def handle_ratelimit_error(e):
    """
    PURPOSE: Catches rate-limiting triggers with appropriate warning message or JSON 429 status.
    ACCESS:  Error handler
    """
    if request.is_json or request.path.startswith('/api/'):
        return jsonify({'error': 'Rate limit exceeded', 'message': 'Too many requests. Please slow down.'}), 429
    flash("Too many requests from your network. Please wait a moment before trying again.", "warning")
    return redirect(request.referrer or url_for('login'))

@app.template_filter('clean_hours')
def clean_hours_filter(val):
    """
    PURPOSE: Jinja template filter formatting proctoring hour floats neatly (e.g. 3.0 -> 3, 3.5 -> 3.5).
    ACCESS:  Template filter
    """
    if val is None or val == '':
        return 0
    try:
        f = float(val)
        return int(f) if f.is_integer() or f % 1 == 0 else round(f, 1)
    except (ValueError, TypeError):
        return val

@app.template_filter('exam_time_range')
def exam_time_range_filter(dt, duration=60):
    """
    PURPOSE: Jinja template filter formatting exam start and end times into 12-hour strings (e.g. '08:00 AM - 09:30 AM').
    ACCESS:  Template filter
    """
    if not dt:
        return 'TBD'
    if isinstance(dt, str):
        try:
            dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
        except Exception:
            try:
                dt = datetime.strptime(dt, "%Y-%m-%dT%H:%M")
            except Exception:
                return dt
    try:
        dur = int(duration or 60)
    except (ValueError, TypeError):
        dur = 60
    end_dt = dt + timedelta(minutes=dur)
    return f"{dt.strftime('%I:%M %p')} - {end_dt.strftime('%I:%M %p')}"

@app.template_filter('exam_datetime_range')
def exam_datetime_range_filter(dt, duration=60):
    """
    PURPOSE: Jinja template filter formatting exam date and time span with clean separators.
    ACCESS:  Template filter
    """
    if not dt:
        return 'TBD'
    if isinstance(dt, str):
        try:
            dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
        except Exception:
            try:
                dt = datetime.strptime(dt, "%Y-%m-%dT%H:%M")
            except Exception:
                return dt
    try:
        dur = int(duration or 60)
    except (ValueError, TypeError):
        dur = 60
    end_dt = dt + timedelta(minutes=dur)
    return f"{dt.strftime('%b %d, %Y')} • {dt.strftime('%I:%M %p')} - {end_dt.strftime('%I:%M %p')}" 

def require_role(*roles):
    """
    PURPOSE: Enforces role-based authorization gate, redirecting unauthorized users to their designated role dashboard.
    ACCESS:  Role authorization guard
    """
    redir = require_login()
    if redir:
        return redir
    if session.get('role') not in roles:
        return _redirect_by_role()
    return None

def _redirect_by_role():
    """
    PURPOSE: Determines and routes authenticated users to their corresponding role dashboard based on session.
    ACCESS:  Routing helper
    """
    role = session.get('role')
    if role in ('admin',):
        return redirect(url_for('dashboard'))
    elif role == 'proctor':
        return redirect(url_for('proctor_dashboard'))
    elif role == 'student':
        return redirect(url_for('student_timetable'))
    elif role == 'secretary':
        return redirect(url_for('secretary_dashboard'))
    session.clear()
    return redirect(url_for('login'))

def _get_unread(user_id):
    """
    PURPOSE: Safely queries unread notification count for a specific user ID.
    ACCESS:  Internal notification helper
    """
    try:
        return get_unread_count(user_id)
    except Exception:
        return 0

@app.context_processor
def inject_notifications_unread():
    """
    PURPOSE: Context processor injecting unread notification count and pending student approval counts into templates.
    ACCESS:  Template context processor
    """
    uid = session.get('user_id')
    role = session.get('role')
    unread = _get_unread(uid) if uid else 0
    pending_count = 0
    if role in ('admin', 'super_admin') or session.get('is_super_admin'):
        try:
            pending_count = len(get_pending_users())
        except Exception:
            pending_count = 0
    return {'unread_count': unread, 'pending_count': pending_count}

# ==============================================================================
# SECTION 04: AUTHENTICATION, PASSWORD RESET & LANDING ROUTES
# ==============================================================================

@app.route("/")
def index():
    """
    PURPOSE: Root portal entry point routing logged-in users to their respective dashboards or guests to login.
    ACCESS:  Public / All users
    METHOD:  GET
    """
    if 'user_id' in session:
        if not session.get('role'):
            session.clear()
        else:
            return _redirect_by_role()
    return redirect(url_for('login'))

@app.route("/public/timetable")
def public_timetable():
    """
    PURPOSE: Publicly accessible timetable portal allowing irregular and non-logged-in students to view published schedules by section.
    ACCESS:  Public / Irregular students
    METHOD:  GET
    """
    is_pub = is_schedule_published()
    if not is_pub:
        # Strictly guard against viewing draft timetables via public portal
        return render_template("irregular_portal.html", sections=[], is_published=False)

    section = request.args.get('section', '').strip()
    if not section:
        all_exams = get_schedule_results()
        sections = sorted(list(set(e.get('section', '').strip() for e in all_exams if e.get('section', '').strip() and e.get('status') == 'Scheduled')))
        return render_template("irregular_portal.html", sections=sections, is_published=True)

    exams = get_public_timetable(section=section)
    grouped = defaultdict(list)
    for exam in exams:
        dt = exam['exam_date_time']
        if not dt: continue
        if isinstance(dt, str):
            dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
        exam['time']     = dt.strftime("%I:%M %p")
        exam['time_end'] = (dt + timedelta(minutes=int(exam['duration_minutes'] or 60))).strftime("%I:%M %p")
        grouped[dt.strftime("%A, %B %d, %Y")].append(exam)
    sorted_groups = sorted(grouped.items(), key=lambda x: datetime.strptime(x[0], "%A, %B %d, %Y"))

    return render_template("student_timetable.html",
                           grouped=sorted_groups,
                           total=len(exams),
                           section=section,
                           full_name="Irregular Student Viewer",
                           institute_name="City College of Angeles",
                           exam_term=get_exam_term()[0],
                           exam_semester=get_exam_term()[1],
                           is_published=True)


@app.route("/forgot_password", methods=["GET", "POST"])
@limiter.limit("5 per minute", methods=["POST"])
def forgot_password():
    """
    PURPOSE: Initiates self-service password reset by generating and emailing a secure, time-sensitive token link.
    ACCESS:  Public / Unauthenticated
    METHOD:  GET, POST
    """
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower().replace('ñ', 'n').replace('Ñ', 'n')
        user = get_user_by_email(email)
        if user:
            token = secrets.token_urlsafe(32)
            expiry = datetime.now() + timedelta(hours=1)
            set_password_reset_token(email, token, expiry)
            
            reset_link = url_for('reset_password', token=token, _external=True)
            success, msg = send_reset_email(email, reset_link)
            
            if success:
                flash("Password reset link sent to your email.", "success")
            else:
                flash(f"Error sending email. (Check terminal for test link). Error: {msg}", "warning")
        else:
            # For security, don't reveal if email exists, just say we sent it
            flash("If that email is registered, a reset link was sent.", "info")
            
        return redirect(url_for("login"))
    return render_template("forgot_password.html")

@app.route("/reset_password/<token>", methods=["GET", "POST"])
@limiter.limit("5 per minute", methods=["POST"])
def reset_password(token):
    """
    PURPOSE: Validates password reset token and allows the user to securely set a new password meeting security standards.
    ACCESS:  Public / With valid token
    METHOD:  GET, POST
    """
    user = get_user_by_reset_token(token)
    
    if not user:
        flash("Invalid or expired reset link.", "error")
        return redirect(url_for("login"))
        
    # Check expiry
    if user['reset_token_expiry'] and user['reset_token_expiry'] < datetime.now():
        flash("Reset link has expired. Please request a new one.", "error")
        return redirect(url_for("forgot_password"))
        
    if request.method == "POST":
        new_password = request.form.get("password")
        confirm = request.form.get("confirm_password")
        
        is_valid, err_msg = validate_password_strength(new_password)
        if not is_valid:
            flash(err_msg, "error")
            return render_template("reset_password.html", token=token)
            
        if new_password != confirm:
            flash("Passwords do not match.", "error")
            return render_template("reset_password.html", token=token)
            
        from system.logic import hash_password
        hashed = hash_password(new_password)
        clear_reset_token_and_update_password(token, hashed)
        
        flash("Password successfully reset! You can now log in.", "success")
        return redirect(url_for("login"))
        
    return render_template("reset_password.html", token=token)

@app.route("/login", methods=["GET", "POST"])
@limiter.limit("15 per minute", methods=["POST"])
def login():
    """
    PURPOSE: Primary authentication endpoint validating institutional credentials, initializing sessions, and logging audit events.
    ACCESS:  Public / All users
    METHOD:  GET, POST
    """
    # Step 1: If GET request, redirect if session exists, else render login view with active sections
    if request.method == "GET":
        if 'user_id' in session and session.get('role'):
            return _redirect_by_role()
        all_exams = get_schedule_results()
        sections = sorted(list(set(e.get('section', '').strip() for e in all_exams if e.get('section', '').strip() and e.get('status') == 'Scheduled')))
        # Toggle Demo Accounts card on login page (defaults to False for security)
        show_demo = os.environ.get('SHOW_DEMO_ACCOUNTS', 'False').lower() in ('true', '1', 'yes')
        return render_template("login.html", sections=sections, show_demo=show_demo)

    # Step 2: Handle POST request - extract credentials and verify against bcrypt hash
    email    = request.form.get("email", "").strip().lower().replace('ñ', 'n').replace('Ñ', 'n')
    password = request.form.get("password", "").strip()
    user = verify_login(email, password)

    # Step 3: Check for pending/inactive student or proctor accounts
    if user == 'inactive':
        flash("Your account is pending admin approval. You will be notified once it is activated.", "warning")
        return redirect(url_for('login'))

    # Step 4: If credentials are valid, initialize secure session and log audit trail
    if user:
        session.clear()
        session['user_id']        = user['id']
        session['full_name']      = user['full_name']
        session['role']           = user.get('role', 'student')
        session['email']          = user.get('email', email)
        session['instructor_id']  = user.get('instructor_id')
        session['is_super_admin'] = bool(user.get('is_super_admin', 0))
        session['section']        = user.get('section', '')
        session['institute_id']   = user.get('institute_id')
        import time as _time
        session['_last_active']   = _time.time()
        log_audit_event('AUTH_LOGIN_SUCCESS', f"User authenticated as {user.get('role')}", user_id=user['id'], user_name=user['full_name'], user_role=user.get('role'), ip_address=request.remote_addr)
        return _redirect_by_role()

    # Step 5: Log failed attempt for brute-force tracking and display error notification
    log_audit_event('AUTH_LOGIN_FAILED', f"Failed login attempt for: {email}", ip_address=request.remote_addr)
    flash("Invalid email or password.", "error")
    return redirect(url_for('login'))


@app.route("/logout")
def logout():
    """
    PURPOSE: Terminates user session, logs audit trail entry, and redirects user to login portal.
    ACCESS:  Authenticated users
    METHOD:  GET
    """
    log_audit_event('AUTH_LOGOUT', "User logged out", user_id=session.get('user_id'), user_name=session.get('full_name'), user_role=session.get('role'), ip_address=request.remote_addr)
    session.clear()
    return redirect(url_for('login'))

# ==============================================================================
# SECTION 05: STUDENT SELF-REGISTRATION & LEGAL PAGES
# ==============================================================================

@app.route("/terms")
def terms_page():
    """
    PURPOSE: Displays institutional Terms of Service and examination platform guidelines.
    ACCESS:  Public
    METHOD:  GET
    """
    return render_template("terms.html")

@app.route("/privacy")
def privacy_page():
    """
    PURPOSE: Displays institutional Data Privacy compliance disclosure statement.
    ACCESS:  Public
    METHOD:  GET
    """
    return render_template("privacy.html")

@app.route("/register", methods=["GET"])
def register_page():
    """
    PURPOSE: Renders student self-registration form with institute and section dropdowns.
    ACCESS:  Public / New students
    METHOD:  GET
    """
    if 'user_id' in session:
        return _redirect_by_role()
    institutes = get_all_institutes()
    
    # Get distinct sections
    sections = []
    from system.database import open_db
    db = open_db()
    if db:
        try:
            cursor = db.cursor()
            cursor.execute("SELECT DISTINCT section FROM (SELECT section FROM users WHERE section IS NOT NULL AND section != '' UNION SELECT section FROM exams WHERE section IS NOT NULL AND section != '') AS all_sections ORDER BY section")
            sections = [r[0] for r in cursor.fetchall()]
        finally:
            db.close()
            
    return render_template("register.html", institutes=institutes, sections=sections)

@app.route("/register", methods=["POST"])
@limiter.limit("10 per minute")
def register_submit():
    """
    PURPOSE: Validates and saves new student self-registration, placing account in pending administrative approval queue.
    ACCESS:  Public / New students
    METHOD:  POST
    """
    # Step 1: Extract and sanitize user registration form fields
    first_name   = request.form.get("first_name", "").strip()
    last_name    = request.form.get("last_name", "").strip()
    middle_name  = request.form.get("middle_name", "").strip()
    suffix       = request.form.get("suffix", "").strip()
    
    # Format the name: "Lastname, Firstname M. Suffix"
    middle_initial = (middle_name[0].upper() + ".") if middle_name else ""
    full_name_parts = [part for part in [first_name, middle_initial, suffix] if part]
    formatted_first_part = " ".join(full_name_parts)
    full_name = f"{last_name}, {formatted_first_part}" if last_name and formatted_first_part else (last_name or formatted_first_part)
    email        = request.form.get("email", "").strip().lower().replace('ñ', 'n').replace('Ñ', 'n')
    password     = request.form.get("password", "").strip()
    section      = request.form.get("section", "").strip()
    institute_id = int(request.form.get("institute_id")) if request.form.get("institute_id") and request.form.get("institute_id").strip().isdigit() and int(request.form.get("institute_id")) > 0 else None
    role         = request.form.get("role", "student").strip()
    
    if role not in ['student', 'proctor']:
        role = 'student'
        
    # Step 2: Validate institutional domain requirement (@cca.edu.ph)
    if not email.endswith("@cca.edu.ph"):
        flash("Registration is restricted to @cca.edu.ph email addresses only.", "danger")
        return redirect(url_for('register_page'))
        
    # Step 3: Validate password complexity against NIST guidelines
    is_valid, err_msg = validate_password_strength(password)
    if not is_valid:
        flash(err_msg, "danger")
        return redirect(url_for('register_page'))

    if not full_name or not email or not password:
        flash("All fields are required.", "danger")
        return redirect(url_for('register_page'))
        
    # Step 4: Check if email is already registered to prevent duplicates
    user_exists = get_user_by_email(email)
    if user_exists:
        flash("That email is already registered.", "danger")
        return redirect(url_for('register_page'))

    # Step 5: Insert user record in pending approval status (is_active = 0)
    result = register_user(full_name, email, password, role, section=section, institute_id=institute_id)
                           
    if result == 'ok':
        flash("Account created! Your registration is pending admin approval. You will be notified once it is activated.", "success")
        return redirect(url_for('login'))
    else:
        flash("Something went wrong saving to the local database.", "danger")
        return redirect(url_for('register_page'))

# ==============================================================================
# SECTION 06: ADMINISTRATIVE DASHBOARD
# ==============================================================================

@app.route("/dashboard")
def dashboard():
    """
    PURPOSE: Main administrative control center displaying operational metrics, resource totals, and schedule summaries.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    stats           = get_dashboard_stats()
    exams           = get_all_exams()
    rooms           = get_all_rooms()
    instructors     = get_all_instructors()
    institutes      = get_all_institutes()
    subjects        = get_all_subjects()
    upcoming_exams  = get_upcoming_exams()
    settings        = get_system_settings()
    unread          = _get_unread(session['user_id'])
    pending_count   = len(get_pending_users())
    p_start, p_end  = get_exam_period()
    term_tuple      = get_exam_term()
    exam_term       = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester   = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    is_published    = is_schedule_published()
    return render_template("dashboard.html",
                           stats=stats, exams=exams,
                           rooms=rooms, instructors=instructors,
                           buildings=get_all_buildings(),
                           institutes=institutes, subjects=subjects,
                           upcoming_exams=upcoming_exams,
                           settings=settings,
                           unread_count=unread,
                           pending_count=pending_count,
                           period_start=p_start,
                           period_end=p_end,
                           exam_term=exam_term,
                           exam_semester=exam_semester,
                           is_published=is_published)

# ==============================================================================
# SECTION 07: RESOURCE CRUD OPERATIONS (ROOMS, INSTRUCTORS, EXAMS)
# ==============================================================================

@app.route("/add_exam", methods=["POST"])
def add_exam_route():
    """
    PURPOSE: Creates an examination request for a specific course, section, and duration into the scheduling pool.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    subject_id = request.form.get("subject_id")
    section = request.form.get("section", "").strip().upper()
    raw_type = request.form.get("subject_type", "Major").strip()
    st_norm = raw_type.lower()
    subject_type = 'Minor' if st_norm in ('minor', 'laboratory', 'lab') else 'Major'
    
    dur_hrs = request.form.get("duration_hours")
    if dur_hrs:
        try:
            duration_minutes = int(round(float(dur_hrs) * 60))
        except (ValueError, TypeError):
            duration_minutes = 180 if subject_type == 'Major' else 60
    else:
        duration_minutes = 180 if subject_type == 'Major' else 60

    institute_id = int(request.form.get("institute_id")) if request.form.get("institute_id") and request.form.get("institute_id").strip().isdigit() and int(request.form.get("institute_id")) > 0 else None
    
    subject_name = ""
    if subject_id:
        from system.database import get_subject_by_id
        sub = get_subject_by_id(subject_id)
        if sub:
            subject_name = sub.get('name') or sub.get('code') or ''

    add_exam(subject_name, section, subject_type, duration_minutes, institute_id, subject_id)
    flash(f"Exam '{subject_name}' ({section}) added successfully.", "success")
    return redirect(url_for('dashboard') + '#exams')

@app.route("/add_room", methods=["POST"])
def create_room():
    """
    PURPOSE: Registers a new examination room in the campus inventory with seating capacity and PWD accessibility flags.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    room_name = request.form.get("room_name", "").strip()
    building = request.form.get("building", "").strip()
    if building == '__new__':
        building = request.form.get("new_building_name", "").strip() or "Main Building"
    
    existing_rooms = get_all_rooms()
    if any(r['room_name'].lower() == room_name.lower() and r.get('building', '').lower() == building.lower() for r in existing_rooms):
        flash(f"Warning: Room '{room_name}' already exists in that building.", "error")
        return redirect(url_for('dashboard') + '#rooms')

    add_room(
        room_name,
        request.form.get("capacity"),
        building=building,
        floor=request.form.get("floor", 1),
        institute_id=int(request.form.get("institute_id")) if request.form.get("institute_id") and request.form.get("institute_id").strip().isdigit() and int(request.form.get("institute_id")) > 0 else None,
        is_pwd_accessible=1 if request.form.get("is_pwd_accessible") else 0
    )
    flash("Room added successfully.", "success")
    return redirect(url_for('dashboard') + '#rooms')

@app.route("/edit_room/<int:id>", methods=["POST"])
@app.route("/rooms/<int:id>/edit", methods=["POST"])
def edit_room_route(id):
    """
    PURPOSE: Updates existing room attributes including building location, seating capacity, and accessibility status.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    room_name = request.form.get("room_name", "").strip()
    try:
        capacity = int(request.form.get("capacity") or 0)
    except (ValueError, TypeError):
        capacity = 0
    building = request.form.get("building", "").strip()
    if building == '__new__':
        building = request.form.get("new_building_name", "").strip() or "Main Building"
    try:
        floor = int(request.form.get("floor") or 1)
    except (ValueError, TypeError):
        floor = 1
    institute_id = int(request.form.get("institute_id")) if request.form.get("institute_id") and request.form.get("institute_id").strip().isdigit() and int(request.form.get("institute_id")) > 0 else None
    is_pwd_accessible = 1 if request.form.get("is_pwd_accessible") else 0
    edit_room(id, room_name, capacity, building, floor, institute_id, is_pwd_accessible)
    flash(f"Room '{room_name}' updated successfully.", "success")
    return redirect(url_for('dashboard') + '#rooms')

@app.route("/delete_room/<int:id>", methods=["POST"])
@app.route("/rooms/<int:id>/delete", methods=["POST"])
def delete_room_route(id):
    """
    PURPOSE: Removes an individual examination room from the campus inventory.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    err = delete_room(id)
    if err:
        flash("Could not delete room. Please verify it is not in use.", "danger")
    else:
        flash("Room deleted successfully.", "success")
    return redirect(url_for('dashboard') + '#rooms')

@app.route("/rooms/bulk_delete", methods=["POST"])
def rooms_bulk_delete():
    """
    PURPOSE: Bulk deletes multiple selected rooms from the inventory.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    ids = request.form.getlist("room_ids")
    deleted, errors = 0, []
    for rid in ids:
        try:
            err = delete_room(int(rid))
            if err:
                errors.append(err)
            else:
                deleted += 1
        except Exception as e:
            errors.append(str(e))
    if deleted:
        flash(f"{deleted} room(s) deleted successfully.", "success")
    if errors:
        flash(f"{len(errors)} room(s) could not be deleted: {errors[0]}", "warning")
    return redirect(url_for('dashboard') + '#rooms')

@app.route("/api/buildings", methods=["GET"])
def api_get_buildings():
    """
    PURPOSE: Returns real-time list of all campus buildings with assigned room and faculty counts.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return jsonify({'error': 'Unauthorized'}), 403
    return jsonify({'buildings': get_buildings_summary()})

@app.route("/api/buildings/delete", methods=["POST"])
def api_delete_building():
    """
    PURPOSE: Safely deletes a custom building, reassigning any assigned rooms or faculty to Main Building.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json(silent=True) or request.form
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({'error': 'Building name is required.'}), 400
    
    ok, msg = delete_custom_building(name, fallback="Main Building")
    if ok:
        log_audit_event('BUILDING_DELETED', f"Deleted custom building '{name}' and reassigned dependencies to Main Building.")
        return jsonify({'success': True, 'message': msg})
    else:
        return jsonify({'error': msg}), 400

@app.route("/add_instructor", methods=["POST"])
def add_instructor_route():
    """
    PURPOSE: Registers a new faculty member with department affiliation, taught subjects, and proctoring eligibility.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    
    last = request.form.get("last_name", "").strip()
    first = request.form.get("first_name", "").strip()
    middle = request.form.get("middle_name", "").strip()
    suffix = request.form.get("suffix", "").strip()
    
    if last and first:
        full_name = f"{last}, {first}"
        if middle:
            full_name += f" {middle[0]}." if len(middle) == 1 else f" {middle}"
        if suffix:
            full_name += f" {suffix}"
    else:
        full_name = request.form.get("name", "").strip()
        
    building = request.form.get("building", "").strip()
    if building == '__new__':
        building = request.form.get("new_building_name", "").strip() or "Main Building"

    add_instructor(
        full_name,
        (int(request.form.get("institute_id")) if request.form.get("institute_id") and request.form.get("institute_id").strip().isdigit() and int(request.form.get("institute_id")) > 0 else None),
        building,
        1 if request.form.get("is_pwd") else 0,
        request.form.get("subjects_taught", "")
    )
    flash("Instructor added.", "success")
    return redirect(url_for('faculty_page'))

@app.route("/delete_instructor/<int:id>", methods=["POST"])
@app.route("/faculty/<int:id>/delete", methods=["POST"])
def remove_instructor(id):
    """
    PURPOSE: Deletes an instructor/proctor record from the institutional roster.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    err = delete_instructor(id)
    if err:
        flash("Could not delete instructor. Please verify they are not assigned to active exams.", "danger")
    else:
        flash("Instructor deleted successfully.", "success")
    return redirect(url_for('faculty_page'))

@app.route("/faculty/bulk_delete", methods=["POST"])
@app.route("/instructors/bulk_delete", methods=["POST"])
def faculty_bulk_delete():
    """
    PURPOSE: Bulk deletes multiple selected faculty members from the roster.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    ids = request.form.getlist("instructor_ids")
    deleted, errors = 0, []
    for sid in ids:
        try:
            err = delete_instructor(int(sid))
            if err:
                errors.append(err)
            else:
                deleted += 1
        except Exception as e:
            errors.append(str(e))
    if deleted:
        flash(f"{deleted} instructor(s) deleted successfully.", "success")
    if errors:
        flash(f"{len(errors)} instructor(s) could not be deleted: " + "; ".join(errors), "warning")
    ref = request.referrer or ''
    if 'dashboard' in ref:
        return redirect(url_for('dashboard') + '#instructors')
    return redirect(url_for('faculty_page'))


@app.route("/delete_exam/<int:id>", methods=["POST"])
def remove_exam(id):
    """
    PURPOSE: Deletes a specific exam entry from the timetable or pending requests pool.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    delete_exam(id)
    log_audit_event('EXAM_DELETE', f"Deleted exam ID {id}", user_id=session.get('user_id'), user_name=session.get('full_name'), user_role=session.get('role'), ip_address=request.remote_addr)
    flash('Exam deleted.', 'success')
    return redirect(url_for('dashboard') + '#exams')

@app.route("/delete_all_exams", methods=["POST"])
def remove_all_exams():
    """
    PURPOSE: Clears all scheduled and unscheduled exam records across the active academic term.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    count = delete_all_exams()
    log_audit_event('EXAM_DELETE_ALL', f"Purged all {count} exams from system", user_id=session.get('user_id'), user_name=session.get('full_name'), user_role=session.get('role'), ip_address=request.remote_addr)
    flash(f' All {count} exam(s) deleted successfully.', 'success')
    return redirect(url_for('dashboard') + '#exams')

# ==============================================================================
# SECTION 08: SCHEDULING ENGINE INTEGRATION & TIMETABLE MANAGEMENT
# ==============================================================================

@app.route("/generate_schedule", methods=["POST"])
def generate_schedule():
    """
    PURPOSE: Invokes the automated constraint satisfaction algorithm to schedule all unscheduled exams without collisions.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard

    # Guard 1: Cannot generate/regenerate while timetable is published live
    if is_schedule_published():
        flash("Cannot generate or modify timetable while the schedule is Published and live. Please unpublish the timetable first.", "warning")
        return redirect(url_for('schedule_view'))

    # Guard 2: Cannot generate/regenerate while a Schedule Reset Request is pending Super Admin authorization
    pending_reset = get_pending_schedule_reset_request()
    if pending_reset:
        flash(f"Timetable generation is locked because a Schedule Reset Request (submitted by {pending_reset.get('requested_by_name')}) is currently awaiting Super Admin authorization.", "warning")
        return redirect(url_for('schedule_view'))

    # Step 1: Extract and validate examination term and period dates
    period_start_str = request.form.get("period_start")
    period_end_str   = request.form.get("period_end")
    day_start_str    = request.form.get("day_start")
    day_end_str      = request.form.get("day_end")
    
    exam_term = request.form.get("exam_term", "Midterm")
    exam_semester = request.form.get("exam_semester", "1st Semester")
    save_exam_term(exam_term, exam_semester)
    try:
        period_start = date.fromisoformat(period_start_str)
        period_end   = date.fromisoformat(period_end_str)
    except (TypeError, ValueError):
        flash("Please select a valid exam period.", "warning")
        return redirect(url_for('schedule_view'))

    if period_end < period_start:
        flash("End date must be after start date.", "warning")
        return redirect(url_for('schedule_view'))

    span_days = (period_end - period_start).days + 1
    save_exam_period(period_start, period_end)
    
    settings = get_system_settings()
    if day_start_str and day_end_str:
        try:
            parts = day_end_str.strip().split(':')
            if len(parts) >= 2 and int(parts[0]) <= 11:
                day_end_str = f"{int(parts[0]) + 12:02d}:{parts[1]}"
        except Exception:
            pass
        save_system_settings(
            day_start=day_start_str,
            day_end=day_end_str,
            slot_interval_min=settings.get('slot_interval_min', 60),
            max_proctor_hrs=settings.get('max_consecutive_proctor_hrs', 3.0),
            travel_buffer_min=settings.get('travel_buffer_min', 15),
            smtp_host=settings.get('smtp_host', ''),
            smtp_port=settings.get('smtp_port', 587),
            smtp_user=settings.get('smtp_user', ''),
            smtp_password=settings.get('smtp_password', ''),
            smtp_from=settings.get('smtp_from', ''),
            smtp_use_tls=settings.get('smtp_use_tls', 1),
            major_duration_hrs=settings.get('major_duration_hrs', 3.0),
            minor_duration_hrs=settings.get('minor_duration_hrs', 1.0),
            max_daily_proctor_hrs=settings.get('max_daily_proctor_hrs', 4.0)
        )
        settings = get_system_settings() # reload

    # Ensure all exams and subjects have consistent CCA institute assignments before scheduling
    sync_exam_and_subject_institutes()

    raw_institute_id = request.form.get("institute_id", "").strip()
    target_institute_id = int(raw_institute_id) if raw_institute_id and raw_institute_id.isdigit() else None

    is_regenerate = bool(request.form.get("regenerate_all"))
    existing_scheduled = get_already_scheduled_slots()

    # Guard 3: Dual-Authorization enforcement on Fresh Regeneration (Wipe & Reschedule)
    if is_regenerate and existing_scheduled:
        if not session.get('is_super_admin'):
            log_audit_event('SCHEDULE_REGEN_BLOCKED',
                f"Admin {session.get('full_name')} attempted unapproved fresh schedule regeneration while {len(existing_scheduled)} scheduled exams exist.",
                user_id=session.get('user_id'),
                user_name=session.get('full_name'),
                user_role=session.get('role'),
                ip_address=request.remote_addr
            )
            flash("Fresh regeneration (wiping the active timetable) is restricted to Super Administrators under the Dual-Authorization policy. Please submit a Schedule Reset Request for administrative review.", "warning")
            return redirect(url_for('schedule_view', institute_id=target_institute_id) if target_institute_id else url_for('schedule_view'))

        # Super Admin authorized fresh regeneration: create archive snapshot before wiping
        term_tuple = get_exam_term()
        exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
        exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
        create_exam_archive(
            academic_year="2025-2026",
            exam_term=exam_term,
            exam_semester=exam_semester,
            archive_title=None,
            notes=f"Automatically archived prior to Super Admin fresh schedule regeneration by {session.get('full_name')}.",
            user_id=session.get('user_id'),
            user_name=session.get('full_name')
        )
        reset_schedule(institute_id=target_institute_id)
        booked = get_already_scheduled_slots() if target_institute_id else []
        pending = get_pending_exams(institute_id=target_institute_id)
    else:
        pending     = get_pending_exams(institute_id=target_institute_id)
        booked      = get_already_scheduled_slots()

    is_fresh_generation = bool(is_regenerate or not booked)

    rooms       = get_all_rooms()
    instructors = get_active_instructors()
    proctor_av  = get_proctor_availability()
    settings    = get_system_settings()

    if not rooms:
        flash(" No rooms found. Add at least one room first.", "warning")
        return redirect(url_for('schedule_view'))
    if not instructors:
        flash(" No active instructors found.", "warning")
        return redirect(url_for('schedule_view'))
    if not pending:
        if session.get('is_super_admin'):
            if target_institute_id:
                flash("All exams for the selected institute are already scheduled. Check 'Fresh Regeneration' to wipe and reschedule them.", "info")
            else:
                flash("All exams are already scheduled. Check 'Fresh Regeneration' to wipe and recreate a fresh schedule from scratch.", "info")
        else:
            flash("All exams are already scheduled. To wipe and recreate a fresh schedule from scratch, please submit a Schedule Reset Request for Super Admin authorization.", "info")
        return redirect(url_for('schedule_view', institute_id=target_institute_id) if target_institute_id else url_for('schedule_view'))

    result = run_scheduler(
        pending_exams=pending,
        rooms=rooms,
        instructors=instructors,
        booked_slots=booked,
        period_start=period_start,
        period_end=period_end,
        proctor_availability=proctor_av,
        settings=settings
    )

    failed_ids = [f['exam_id'] for f in result['failed']]
    unpublish_schedule()  # Newly generated schedule starts in unapproved Draft mode BEFORE applying results
    apply_schedule_results(result['scheduled'], failed_ids)
    session.pop('last_failed', None)  # Never store full failed list in cookie header (prevents Nginx 502 Bad Gateway)
    session['last_failed_flag']     = 1 if failed_ids else 0
    session['last_scheduled_count'] = len(result['scheduled'])
    log_audit_event('SCHEDULE_GENERATED',
        f"Automated schedule generation run by {session.get('full_name')}. Scheduled: {len(result['scheduled'])}, Unscheduled: {len(failed_ids)}. Period: {period_start} to {period_end}.",
        user_id=session.get('user_id'),
        user_name=session.get('full_name'),
        user_role=session.get('role'),
        ip_address=request.remote_addr
    )

    # Note: Broadcast emails are NOT dispatched during draft generation
    # to prevent spamming proctors with tentative assignments. Official notifications
    # are dispatched in a single batch only when 'Finalize & Publish Timetable' is executed.

    inst_label = ""
    if target_institute_id:
        try:
            for inst in get_all_institutes():
                if inst.get('id') == target_institute_id:
                    inst_label = f" for {inst.get('name')}"
                    break
        except Exception:
            pass

    flash(f" Scheduled {len(result['scheduled'])} exam(s){inst_label}. "
          f"{len(result['failed'])} could not be placed.", "success")
    if is_fresh_generation and span_days < 5:
        flash(f"Exam period is only {span_days} day(s). With 1,000+ exams across all sections, scheduling requires at least a 5 to 6-day period (e.g., Oct 26 to Oct 31) because student regulations limit each section to at most 2 Major exams per day.", "warning")
    return redirect(url_for('schedule_view', institute_id=target_institute_id) if target_institute_id else url_for('schedule_view'))

@app.route("/reset_schedule", methods=["POST"])
def reset_schedule_route():
    """
    PURPOSE: Clears all assigned timeslots, rooms, and proctors, reverting exams to unscheduled draft status.
    ACCESS:  Super Admin (or Admin if reset request approved)
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard

    # Enforce Maker-Checker (Dual Authorization)
    # Direct execution is reserved exclusively for Super Administrators
    if not session.get('is_super_admin'):
        flash("Direct schedule reset is restricted to Super Administrators. Please submit a Schedule Reset Request for administrative approval.", "warning")
        return redirect(url_for('schedule_view'))

    # Auto-archive snapshot before wiping
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    create_exam_archive(
        academic_year="2025-2026",
        exam_term=exam_term,
        exam_semester=exam_semester,
        archive_title=None,
        notes="Automatically archived prior to Super Admin direct schedule reset.",
        user_id=session.get('user_id'),
        user_name=session.get('full_name')
    )
    reset_schedule()
    session.pop('last_failed', None)
    session.pop('last_scheduled_count', None)

    # Mark any pending requests as resolved
    db = open_db()
    if db:
        try:
            c = db.cursor()
            c.execute("UPDATE schedule_reset_requests SET status = 'approved', reviewed_by_id = %s, reviewed_by_name = %s, reviewed_at = NOW() WHERE status = 'pending'", (session.get('user_id'), session.get('full_name')))
            db.commit()
        finally:
            db.close()

    log_audit_event('SCHEDULE_RESET_DIRECT', f"Super Admin {session.get('full_name')} performed direct schedule reset. Archive snapshot saved.", user_id=session.get('user_id'), user_name=session.get('full_name'), user_role='super_admin', ip_address=request.remote_addr)
    flash('Schedule reset successfully. Current timetable was archived, and all exams have returned to Pending.', 'success')
    return redirect(url_for('schedule_view'))


@app.route("/admin/request_schedule_reset", methods=["POST"])
def admin_request_schedule_reset():
    """
    PURPOSE: Allows Admin to submit a formal schedule reset request to Super Admin with justification notes.
    ACCESS:  Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard

    reason = request.form.get("reason", "").strip()
    if not reason:
        flash("Please provide a justification/reason for requesting a schedule reset.", "warning")
        return redirect(url_for('schedule_view'))

    ok, msg = create_schedule_reset_request(session['user_id'], session.get('full_name', 'Admin'), reason)
    if ok:
        flash(msg, "info")
    else:
        flash(msg, "warning")
    return redirect(url_for('schedule_view'))


@app.route("/super_admin/approve_schedule_reset/<int:request_id>", methods=["POST"])
def super_approve_schedule_reset(request_id):
    """
    PURPOSE: Super Admin approves pending schedule reset request, executing timetable reset and notifying the requester.
    ACCESS:  Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard

    ok, msg = approve_schedule_reset_request(request_id, session['user_id'], session.get('full_name', 'Super Admin'))
    if ok:
        flash(msg, "success")
    else:
        flash(msg, "danger")
    ref = request.referrer
    if ref and ('schedule' in ref or 'super_admin' in ref):
        return redirect(ref)
    return redirect(url_for('super_admin_page'))


@app.route("/super_admin/reject_schedule_reset/<int:request_id>", methods=["POST"])
def super_reject_schedule_reset(request_id):
    """
    PURPOSE: Super Admin rejects pending schedule reset request with administrative reason feedback.
    ACCESS:  Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard

    rejection_reason = request.form.get("rejection_reason", "").strip()
    ok, msg = reject_schedule_reset_request(request_id, session['user_id'], session.get('full_name', 'Super Admin'), rejection_reason)
    if ok:
        flash(msg, "info")
    else:
        flash(msg, "danger")
    ref = request.referrer
    if ref and ('schedule' in ref or 'super_admin' in ref):
        return redirect(ref)
    return redirect(url_for('super_admin_page'))

def log_email_event(msg):
    """
    PURPOSE: Records an email transmission audit entry for operational diagnostics.
    ACCESS:  Internal email logger
    """
    try:
        with open('email_log.txt', 'a', encoding='utf-8') as f:
            from datetime import datetime
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except Exception:
        pass

def send_single_email_sync(to_email, subject, body, bypass_cooldown=False):
    """
    PURPOSE: Synchronously transmits an individual email message via Brevo API or Flask-Mail.
    ACCESS:  Internal email dispatcher
    """
    if not bypass_cooldown and not _can_send_email(to_email, subject):
        return True, "Suppressed by anti-spam cooldown"
    try:
        s = get_system_settings()
        brevo_key = os.environ.get('BREVO_API_KEY') or s.get('brevo_api_key')
        smtp_pw = (s.get('smtp_password') or '').replace(' ', '').strip()
        if not brevo_key and smtp_pw.startswith('xkeysib-'):
            brevo_key = smtp_pw

        if brevo_key:
            sender_email = s.get('smtp_from') or s.get('smtp_user') or "jpbaltazar23-0368@cca.edu.ph"
            from system.mailer import send_via_brevo
            ok, msg = send_via_brevo(brevo_key, to_email, subject, body, sender_email=sender_email)
            log_email_event(f"BREVO -> {to_email} | ok={ok} | {msg}")
            return ok, msg
    except Exception as e:
        log_email_event(f"BREVO EXCEPTION -> {to_email} | {e}")
        print(f"[Mail Single Brevo Error] {e}")

    if app.config.get('MAIL_SERVER'):
        try:
            with app.app_context():
                msg = MailMessage(subject=subject, recipients=[to_email], body=body)
                mail.send(msg)
                return True, "Sent via SMTP"
        except Exception as e:
            return False, str(e)
    return False, "No mail service configured"

def _dispatch_publish_emails_async(admin_email=None, admin_name=None):
    """
    PURPOSE: Asynchronously queries all active proctors and students to send published schedule email notifications.
    ACCESS:  Internal asynchronous worker
    """
    import threading
    import time
    from collections import defaultdict
    global _PUBLISH_IN_PROGRESS

    with _PUBLISH_EMAIL_LOCK:
        if _PUBLISH_IN_PROGRESS:
            log_email_event("DISPATCH_SKIPPED: A publish broadcast is already in progress.")
            return False
        _PUBLISH_IN_PROGRESS = True

    def _run():
        global _PUBLISH_IN_PROGRESS
        log_email_event(f"DISPATCH_START: admin_email={admin_email}")
        sent_recipients = set()
        try:
            db = open_db()
            if not db:
                return
            cursor = db.cursor(dictionary=True)

            # 0. Send confirmation to Admin who clicked Publish
            if admin_email and admin_email.strip().lower() not in sent_recipients:
                sent_recipients.add(admin_email.strip().lower())
                adm_name = admin_name or "Administrator"
                admin_body = f"""Dear {adm_name},

The official Examination Timetable for City College of Angeles has been successfully published and is now LIVE!

Timetable Status: Live on Student and Proctor Portals
Portal Link: https://cca-exam.duckdns.org/schedule

Best regards,
CCA Exam Management System"""
                send_single_email_sync(admin_email, "CCA Examination Timetable Published - Admin Confirmation", admin_body, bypass_cooldown=True)

            # 1. Fetch scheduled exams with rooms for proctors
            cursor.execute("""
                SELECT e.instructor_id, e.subject_name, e.section, e.exam_date_time, r.room_name
                FROM exams e
                LEFT JOIN rooms r ON e.room_id = r.id
                WHERE e.status = 'Scheduled' AND e.instructor_id IS NOT NULL
                ORDER BY e.exam_date_time ASC
            """)
            exams_by_instructor = defaultdict(list)
            for exam in cursor.fetchall():
                exams_by_instructor[exam['instructor_id']].append(exam)

            # 2. Fetch and notify PROCTORS (each proctor receives at most 1 duty summary)
            cursor.execute("""
                SELECT u.id as user_id, u.email, u.full_name, u.instructor_id
                FROM users u
                WHERE u.role = 'proctor' AND u.is_active = 1 AND u.email IS NOT NULL AND u.email != ''
            """)
            proctors = cursor.fetchall()
            log_email_event(f"Sending to {len(proctors)} active proctor(s)...")
            for p in proctors:
                try:
                    email = (p.get('email') or '').strip().lower()
                    if not email or email in sent_recipients:
                        continue
                    sent_recipients.add(email)

                    assigned = exams_by_instructor.get(p.get('instructor_id'), [])
                    if assigned:
                        lines = []
                        for ex in assigned:
                            dt = ex['exam_date_time']
                            dt_str = dt.strftime('%B %d, %Y (%A) at %I:%M %p') if dt else 'TBD'
                            room = ex.get('room_name') or 'TBD'
                            lines.append(f"  * {dt_str}\n    Subject: {ex['subject_name']} ({ex['section'] or '-' })\n    Room: {room}")
                        schedule_text = "\n\n".join(lines)
                        body = f"""Dear Prof. {p['full_name']},

The official Examination Timetable for City College of Angeles has been finalized and published!

Here is your assigned proctoring schedule ({len(assigned)} exam session{'s' if len(assigned) > 1 else ''}):

{schedule_text}

You can log in to your Proctor Portal to review full details and download your official Proctor Duty Slip:
https://cca-exam.duckdns.org/proctor/dashboard

Best regards,
CCA Exam Management System"""
                    else:
                        body = f"""Dear Prof. {p['full_name']},

The official Examination Timetable for City College of Angeles has been finalized and published.

You currently do not have any proctoring assignments for this examination period. You may verify your status in your portal:
https://cca-exam.duckdns.org/proctor/dashboard

Best regards,
CCA Exam Management System"""

                    send_single_email_sync(
                        p['email'],
                        "CCA Examination Timetable Published - Proctor Duties",
                        body,
                        bypass_cooldown=True
                    )
                    time.sleep(0.1)
                except Exception as ex_pr:
                    log_email_event(f"Proctor mail error for {p.get('email')}: {ex_pr}")

            # 3. Fetch and notify active SECRETARIES (only once!)
            cursor.execute("""
                SELECT u.email, u.full_name
                FROM users u
                WHERE u.role = 'secretary' AND u.is_active = 1 AND u.email IS NOT NULL AND u.email != ''
            """)
            secretaries = cursor.fetchall()
            for sec in secretaries:
                try:
                    email = (sec.get('email') or '').strip().lower()
                    if not email or email in sent_recipients:
                        continue
                    sent_recipients.add(email)

                    body = f"""Dear {sec['full_name']},

The official Examination Timetable has been finalized and published by the administration.

You may access your Departmental Secretary Dashboard to manage exam collection and monitor attendance:
https://cca-exam.duckdns.org/secretary/dashboard

Best regards,
CCA Exam Management System"""
                    send_single_email_sync(
                        sec['email'],
                        "CCA Examination Timetable Published - Departmental Notice",
                        body,
                        bypass_cooldown=True
                    )
                    time.sleep(0.1)
                except Exception as ex_sec:
                    log_email_event(f"Secretary mail error for {sec.get('email')}: {ex_sec}")

            # 4. Fetch and notify active STUDENTS (strictly de-duplicated)
            cursor.execute("""
                SELECT u.email, u.full_name, u.section
                FROM users u
                WHERE u.role = 'student' AND u.is_active = 1 AND u.email IS NOT NULL AND u.email != ''
            """)
            students = cursor.fetchall()
            log_email_event(f"Sending to {len(students)} active student(s)...")
            for s in students:
                try:
                    email = (s.get('email') or '').strip().lower()
                    if not email or email in sent_recipients:
                        continue
                    sent_recipients.add(email)

                    body = f"""Dear {s['full_name']},

The official Examination Timetable has been officially approved and published!

You can now log in to the Student Portal to view your complete exam schedule, room assignments, and download your Examination Permit:
https://cca-exam.duckdns.org/student/timetable

Best regards,
CCA Exam Management System"""
                    send_single_email_sync(
                        s['email'],
                        "Official CCA Examination Timetable Published",
                        body,
                        bypass_cooldown=True
                    )
                    time.sleep(0.1)
                except Exception as ex_st:
                    log_email_event(f"Student mail error for {s.get('email')}: {ex_st}")

            db.close()
            log_email_event(f"DISPATCH_COMPLETE: Total distinct recipients emailed: {len(sent_recipients)}")
        except Exception as e:
            print(f"[Publish Email Dispatch Error] {e}")
        finally:
            with _PUBLISH_EMAIL_LOCK:
                _PUBLISH_IN_PROGRESS = False

    threading.Thread(target=_run, daemon=True).start()
    return True

def view_email_log():
    """
    PURPOSE: Helper returning live in-memory email delivery log for diagnostics.
    ACCESS:  Internal diagnostic helper
    """
    guard = require_role('admin')
    if guard: return guard
    try:
        with open('email_log.txt', 'r', encoding='utf-8') as f:
            lines = f.readlines()
            log_text = "".join(lines[-100:])
    except Exception as e:
        log_text = f"No email log entries yet: {e}"
    return f"""
    <html><head><title>Live Email Logs</title></head>
    <body style='background:#0f172a;color:#f8fafc;font-family:monospace;padding:24px;'>
      <h2>📬 Live System Email Dispatch Logs</h2>
      <p style='color:#94a3b8'>Showing last 100 entries (<a href='/admin/email_log' style='color:#38bdf8'>Refresh</a> | <a href='/schedule' style='color:#38bdf8'>Back to Schedule</a>)</p>
      <pre style='background:#1e293b;padding:16px;border-radius:8px;border:1px solid #334155;white-space:pre-wrap;font-size:13px;line-height:1.5;'>{log_text}</pre>
    </body></html>"""

@app.route("/schedule/publish", methods=["POST"])
def schedule_publish():
    """
    PURPOSE: Publishes draft timetable, making it visible to students, proctors, and public viewers and triggering broadcast alerts.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    from system.database import publish_schedule
    ok, msg = publish_schedule(user_id=session.get('user_id'))
    if ok:
        log_audit_event('SCHEDULE_PUBLISHED',
            f"Official master timetable published live to student and proctor portals by {session.get('full_name')}.",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role=session.get('role'),
            ip_address=request.remote_addr
        )
        admin_email = None
        admin_name = session.get('full_name', 'Administrator')
        try:
            db_adm = open_db()
            if db_adm:
                cur_adm = db_adm.cursor(dictionary=True)
                cur_adm.execute("SELECT email, full_name FROM users WHERE id=%s", (session.get('user_id'),))
                u_row = cur_adm.fetchone()
                if u_row:
                    admin_email = u_row.get('email')
                    admin_name = u_row.get('full_name') or admin_name
                db_adm.close()
        except Exception:
            pass
        send_emails = bool(request.form.get('send_broadcast_emails'))
        if send_emails:
            _dispatch_publish_emails_async(admin_email=admin_email, admin_name=admin_name)
            flash("Exam timetable has been finalized and published! Notification emails are being dispatched to proctors and students.", "success")
        else:
            flash("Exam timetable has been finalized and published live to student and proctor portals! (Email broadcast skipped to prevent delivery bounces).", "success")
    else:
        flash(f"Failed to publish timetable: {msg}", "danger")
    return redirect(url_for('schedule_view'))

@app.route("/schedule/unpublish", methods=["POST"])
def schedule_unpublish():
    """
    PURPOSE: Reverts published timetable to draft mode, hiding it from public and student view for maintenance.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    from system.database import unpublish_schedule
    ok, msg = unpublish_schedule(user_id=session.get('user_id'))
    if ok:
        log_audit_event('SCHEDULE_UNPUBLISHED',
            f"Official master timetable reverted to draft mode by {session.get('full_name')}.",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role=session.get('role'),
            ip_address=request.remote_addr
        )
        flash("Exam timetable has been reverted to Draft mode. It is now hidden from students, proctors, and secretaries.", "warning")
    else:
        flash(f"Failed to unpublish timetable: {msg}", "danger")
    return redirect(url_for('schedule_view'))

@app.route("/resolve_conflicts", methods=["POST"])
def resolve_conflicts_route():
    """
    PURPOSE: Evaluates schedule conflicts and attempts automated slot rebalancing to clear collisions.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    
    conflict_ids_str = request.form.get("conflict_ids", "")
    if not conflict_ids_str:
        flash("No conflicts to resolve.", "info")
        return redirect(url_for('schedule_view'))
        
    try:
        exam_ids = [int(x.strip()) for x in conflict_ids_str.split(",") if x.strip()]
    except ValueError:
        flash("Invalid conflict IDs.", "danger")
        return redirect(url_for('schedule_view'))
        
    if not exam_ids:
        return redirect(url_for('schedule_view'))
        
    # Unschedule the conflicting exams
    unschedule_exams(exam_ids)
    
    # Run the scheduler again, which will now try to place these newly unscheduled exams
    # while keeping all other scheduled exams locked
    period_start, period_end = get_exam_period()
    if not period_start or not period_end:
        flash("Exam period not set.", "warning")
        return redirect(url_for('schedule_view'))
        
    pending = get_pending_exams()
    rooms = get_all_rooms()
    instructors = get_active_instructors()
    booked = get_already_scheduled_slots()
    proctor_av = get_proctor_availability()
    settings = get_system_settings()
    
    result = run_scheduler(
        pending_exams=pending,
        rooms=rooms,
        instructors=instructors,
        booked_slots=booked,
        period_start=period_start,
        period_end=period_end,
        proctor_availability=proctor_av,
        settings=settings
    )
    
    failed_ids = [f['exam_id'] for f in result['failed']]
    apply_schedule_results(result['scheduled'], failed_ids)
    
    session.pop('last_failed', None)
    session['last_failed_flag'] = 1 if failed_ids else 0
    session['last_scheduled_count'] = len(result['scheduled'])
    
    resolved_info = ""
    if result['scheduled']:
        resolved_details = [f"{e.get('subject_name')} ({e.get('section')})" for e in result['scheduled'][:8]]
        extra_cnt = len(result['scheduled']) - len(resolved_details)
        resolved_info = " Resolved: " + ", ".join(resolved_details) + (f" and {extra_cnt} more" if extra_cnt > 0 else "")

    if failed_ids:
        flash(f"Auto-resolve completed, but {len(failed_ids)} exam(s) could still not be scheduled.{resolved_info}", "warning")
    else:
        flash(f"All conflicts have been successfully auto-resolved!{resolved_info}", "success")
        
    return redirect(url_for('schedule_view'))

@app.route("/api/audit_scheduler_live", methods=["GET"])
def api_audit_scheduler_live():
    """
    PURPOSE: Diagnostic API auditing constraints across all currently scheduled exams and returning detailed collision reports.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_super_admin()
    if guard: return guard
    # Diagnostic endpoint for live server verification
    from system.scheduler import run_scheduler, _to_time
    from datetime import date, time as dt_time, timedelta
    settings = get_system_settings()
    rooms = get_all_rooms()
    instructors = get_active_instructors()
    proctor_av = get_proctor_availability()
    
    test_all = request.args.get('test_all', '0') == '1'
    if test_all:
        db = open_db()
        cur = db.cursor(dictionary=True)
        cur.execute("""
            SELECT e.*, s.content_group_id, s.code AS subject_code, s.name AS subject_catalog_name,
                   COALESCE(inst.capacity_default, 40) AS institute_capacity_default,
                   COALESCE(u_cnt.stu_cnt, 0) AS section_student_count
            FROM exams e
            LEFT JOIN subjects s ON e.subject_id = s.id
            LEFT JOIN institutes inst ON e.institute_id = inst.id
            LEFT JOIN (
                SELECT section, COUNT(*) AS stu_cnt
                FROM users
                WHERE role = 'student' AND section IS NOT NULL
                GROUP BY section
            ) u_cnt ON u_cnt.section = e.section
        """)
        pending = cur.fetchall()
        db.close()
    else:
        pending = get_pending_exams()
        if not pending:
            db = open_db()
            cur = db.cursor(dictionary=True)
            cur.execute("""
                SELECT e.*, s.content_group_id, s.code AS subject_code, s.name AS subject_catalog_name,
                       COALESCE(inst.capacity_default, 40) AS institute_capacity_default,
                       COALESCE(u_cnt.stu_cnt, 0) AS section_student_count
                FROM exams e
                LEFT JOIN subjects s ON e.subject_id = s.id
                LEFT JOIN institutes inst ON e.institute_id = inst.id
                LEFT JOIN (
                    SELECT section, COUNT(*) AS stu_cnt
                    FROM users
                    WHERE role = 'student' AND section IS NOT NULL
                    GROUP BY section
                ) u_cnt ON u_cnt.section = e.section
            """)
            pending = cur.fetchall()
            db.close()
    
    p_start, p_end = get_exam_period()
    if not p_start or not p_end:
        p_start = date(2026, 11, 2)
        p_end = date(2026, 11, 7)
    
    # Custom dates from query params if given
    if request.args.get('start'):
        try: p_start = date.fromisoformat(request.args.get('start'))
        except Exception: pass
    if request.args.get('end'):
        try: p_end = date.fromisoformat(request.args.get('end'))
        except Exception: pass

    # Diagnose XOBLICO group specifically
    x_exams = [e for e in pending if 'XOBLICO' in (e.get('subject_name') or '')]

    res = run_scheduler(
        pending_exams=list(pending),
        rooms=rooms,
        instructors=instructors,
        booked_slots=[],
        period_start=p_start,
        period_end=p_end,
        proctor_availability=proctor_av,
        settings=settings
    )

    from collections import Counter
    sched_times = Counter(s['exam_date_time'].strftime('%H:%M') for s in res.get('scheduled', []))
    
    # Check proctor availability sample
    sample_av = {}
    for iid, entries in list(proctor_av.items())[:3]:
        sample_av[iid] = [{'date': str(e.get('date')), 'start': str(e.get('start_time')), 'end': str(e.get('end_time'))} for e in entries[:2]]

    return jsonify({
        'code_version': 'audit-diagnostic-v6',
        'status': 'success',
        'test_all': test_all,
        'period_start': str(p_start),
        'period_end': str(p_end),
        'day_start_raw': str(settings.get('day_start')),
        'day_end_raw': str(settings.get('day_end')),
        'parsed_day_start': str(_to_time(settings.get('day_start'), dt_time(7,0))),
        'parsed_day_end': str(_to_time(settings.get('day_end'), dt_time(20,0), is_end_of_day=True)),
        'total_exams_input': len(pending),
        'active_rooms': len(rooms),
        'active_instructors': len(instructors),
        'proctor_availability_count': len(proctor_av),
        'sample_proctor_availability': sample_av,
        'xoblico_count': len(x_exams),
        'xoblico_sample': [{k: str(v) for k, v in e.items() if k in ('id', 'subject_name', 'section', 'duration_minutes', 'subject_type', 'content_group_id', 'subject_id')} for e in x_exams[:3]],
        'scheduled_count': len(res.get('scheduled', [])),
        'failed_count': len(res.get('failed', [])),
        'scheduled_start_times': dict(sorted(sched_times.items())),
        'first_3_failures': res.get('failed', [])[:3]
    })

@app.route("/api/db_diagnostic", methods=["GET"])
def api_db_diagnostic():
    """
    PURPOSE: Low-level diagnostic endpoint checking database connectivity and core table record counts.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_super_admin()
    if guard: return guard
    from system.database import audit_schedule_conflicts
    db = open_db()
    cur = db.cursor(dictionary=True)
    cur.execute('SELECT subject_type, duration_minutes, COUNT(*) as cnt FROM exams GROUP BY subject_type, duration_minutes')
    exam_groups = cur.fetchall()
    cur.execute('SELECT COUNT(*) as cnt FROM rooms')
    rooms_cnt = cur.fetchone()['cnt']
    cur.execute('SELECT MIN(capacity) as min_c, MAX(capacity) as max_c, COUNT(*) as zero_cap FROM rooms WHERE capacity IS NULL OR capacity <= 0')
    rooms_cap = cur.fetchone()
    cur.execute('SELECT COUNT(*) as cnt FROM instructors')
    inst_cnt = cur.fetchone()['cnt']
    cur.execute('SELECT COUNT(*) as cnt FROM proctor_availability')
    avail_cnt = cur.fetchone()['cnt']
    cur.execute('SELECT MIN(available_date) as min_d, MAX(available_date) as max_d, MIN(start_time) as min_s, MAX(end_time) as max_e FROM proctor_availability')
    avail_stats = {k: str(v) for k, v in cur.fetchone().items()}
    cur.execute('SELECT COUNT(*) as cnt, COUNT(DISTINCT section) as sections_cnt FROM users WHERE role="student"')
    stu_stats = cur.fetchone()
    cur.execute('SELECT * FROM system_settings WHERE id=1')
    raw_settings = cur.fetchone() or {}
    settings = {}
    for k, v in raw_settings.items():
        if k in ('smtp_password', 'smtp_user'):
            settings[k] = '********' if v else ''
        else:
            settings[k] = str(v) if v is not None else ''
    cur.execute('SELECT status, COUNT(*) as cnt FROM exams GROUP BY status')
    exam_statuses = cur.fetchall()
    cur.execute('SELECT COUNT(*) as null_rooms FROM exams WHERE room_id IS NULL AND status="Scheduled"')
    null_rooms = cur.fetchone()['null_rooms']
    cur.execute('SELECT COUNT(*) as null_insts FROM exams WHERE instructor_id IS NULL AND status="Scheduled"')
    null_insts = cur.fetchone()['null_insts']
    db.close()
    
    audit = audit_schedule_conflicts()
    
    return jsonify({
        'exam_groups': exam_groups,
        'exam_statuses': exam_statuses,
        'null_rooms': null_rooms,
        'null_insts': null_insts,
        'rooms_cnt': rooms_cnt,
        'rooms_cap': rooms_cap,
        'inst_cnt': inst_cnt,
        'avail_cnt': avail_cnt,
        'avail_stats': avail_stats,
        'stu_stats': stu_stats,
        'settings': settings,
        'audit_summary': {
            'is_clean': audit.get('is_clean'),
            'total_exams': audit.get('total_exams'),
            'total_conflicts_count': audit.get('total_conflicts_count'),
            'room_conflicts': len(audit.get('room_conflicts', [])),
            'proctor_conflicts': len(audit.get('proctor_conflicts', [])),
            'section_conflicts': len(audit.get('section_conflicts', [])),
            'break_conflicts': len(audit.get('break_conflicts', [])),
            'subject_conflicts': len(audit.get('subject_conflicts', [])),
            'integrity_conflicts': len(audit.get('integrity_conflicts', [])),
            'sample_room_conflict': audit.get('room_conflicts', [])[:2],
            'sample_section_conflict': audit.get('section_conflicts', [])[:2]
        }
    })

@app.route("/schedule")
def schedule_view():
    """
    PURPOSE: Primary timetable management view displaying scheduled, pending, and conflicted examinations with filter controls.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    all_exams   = get_schedule_results()
    session.pop('last_failed', None)
    had_failed_flag = bool(session.pop('last_failed_flag', 0))
    failed      = []
    
    # Enrich each exam with parsed datetime, formatted strings
    scheduled_exams = []
    unscheduled     = []
    for exam in all_exams:
        if exam['status'] == 'Scheduled':
            dt = exam['exam_date_time']
            if isinstance(dt, str):
                dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
            dur = int(exam.get('duration_minutes') or 60)
            end_dt = dt + timedelta(minutes=dur)
            exam['_dt']          = dt
            exam['_end_dt']      = end_dt
            exam['_date_str']    = dt.strftime("%Y-%m-%d")          # for grouping
            exam['_time_str']    = dt.strftime("%H:%M")             # row key
            exam['time']         = dt.strftime("%I:%M %p")
            exam['time_end']     = end_dt.strftime("%I:%M %p")
            exam['time_range']   = f"{exam['time']} - {exam['time_end']}"
            exam['_date_label']  = dt.strftime("%a %b %d")       # column header
            exam['datetime']     = dt.strftime("%b %d, %Y %I:%M %p")
            exam['datetime_raw'] = dt.strftime("%Y-%m-%dT%H:%M")
            scheduled_exams.append(exam)
        else:
            unscheduled.append(exam)
            if had_failed_flag and exam.get('status') == 'Unscheduled':
                failed.append({
                    'exam_id': exam.get('id'),
                    'subject_name': exam.get('subject_name'),
                    'section': exam.get('section'),
                    'reason': 'No slot found satisfying room, proctor, and section daily load constraints.'
                })

    # Unified conflict audit synchronized with validator
    from system.database import audit_schedule_conflicts
    conflict_audit = audit_schedule_conflicts()
    conflict_ids = conflict_audit.get('conflict_exam_ids', [])
    conflict_reasons = conflict_audit.get('conflict_reasons', {})

    # Unique sections for dropdown filter
    all_sections = sorted(list(set(e.get('section', '').strip() for e in all_exams if e.get('section', '').strip())))
    filter_section = request.args.get('section', '').strip()
    filter_inst_id = request.args.get('institute_id', '').strip()

    # Build timetable grid: unique sorted dates (columns) and time slots (rows)
    dates_set = sorted(set(e['_date_str'] for e in scheduled_exams))
    times_set = sorted(set(e['_time_str'] for e in scheduled_exams))

    # timetable[time_str][date_str] = list of exams
    timetable = defaultdict(lambda: defaultdict(list))
    for exam in scheduled_exams:
        timetable[exam['_time_str']][exam['_date_str']].append(exam)

    # date labels map
    date_labels = {}
    for e in scheduled_exams:
        date_labels[e['_date_str']] = e['_date_label']

    time_labels = {}
    for e in scheduled_exams:
        time_labels[e['_time_str']] = e['time']

    institutes = get_all_institutes()
    unread     = _get_unread(session['user_id'])
    p_start, p_end = get_exam_period()
    return render_template("schedule.html",
                           conflict_audit=conflict_audit,
                           timetable=timetable,
                           dates=dates_set,
                           date_labels=date_labels,
                           time_labels=time_labels,
                           times=times_set,
                           scheduled_exams=scheduled_exams,
                           unscheduled=unscheduled,
                           failed=failed,
                           sched_count=len([e for e in all_exams if e['status'] == 'Scheduled']),
                           total=len(all_exams),
                           conflict_ids=conflict_ids,
                           conflict_reasons=conflict_reasons,
                           rooms=get_all_rooms(),
                           instructors=get_all_instructors(),
                           institutes=institutes,
                           unread_count=unread,
                           all_sections=all_sections,
                           filter_section=filter_section,
                           filter_inst_id=filter_inst_id,
                           exam_term=get_exam_term()[0],
                           exam_semester=get_exam_term()[1],
                           period_start=p_start,
                           period_end=p_end,
                           is_published=is_schedule_published(),
                           pending_reset_request=get_pending_schedule_reset_request())

@app.route("/api/auto_schedule_exam", methods=["POST"])
def api_auto_schedule_exam():
    """
    PURPOSE: Automatically finds the optimal conflict-free room and proctor slot for a single unassigned exam.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return jsonify({})
    data = request.get_json(force=True)
    exam_id = int(data.get('exam_id', 0))
    duration = int(data.get('duration_minutes', 60))
    sync_all = bool(data.get('sync_all', False))
    
    from system.database import get_full_auto_schedule
    result = get_full_auto_schedule(exam_id, duration, sync_all=sync_all)
    return jsonify(result or {})

@app.route("/api/suggest_times", methods=["POST"])
def api_suggest_times():
    """
    PURPOSE: Proposes optimal conflict-free time slots for a specific course and section.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return jsonify([])
    data = request.get_json(force=True)
    exam_id = int(data.get('exam_id', 0))
    duration = int(data.get('duration_minutes', 60))
    room_id = int(data.get('room_id', 0))
    proctor_id = int(data.get('instructor_id', 0))
    
    from system.database import get_suggested_times
    suggestions = get_suggested_times(exam_id, duration, room_id, proctor_id)
    return jsonify({'suggestions': suggestions})

@app.route("/api/available_resources", methods=["POST"])
def available_resources():
    """
    PURPOSE: Returns lists of available rooms and proctors for a specified date and time window.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard:
        return jsonify({'error': 'Not authorised'}), 403
    data = request.get_json(force=True)
    exam_id = int(data.get('exam_id', 0))
    dt_str = data.get('exam_datetime', '')
    duration = int(data.get('duration_minutes', 60))
    if not dt_str:
        return jsonify({'rooms': [], 'instructors': []})
    res = get_available_resources(exam_id, dt_str, duration)
    return jsonify(res)

@app.route("/api/resource_availability", methods=["GET"])
def api_resource_availability():
    """
    PURPOSE: JSON endpoint returning real-time room and proctor availability status for conflict prevention during manual slot editing.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin', 'secretary', 'proctor')
    if guard:
        return jsonify({'error': 'Not authorised'}), 403
    res_type = request.args.get('type', '').strip().lower()
    res_id   = request.args.get('id', '').strip()
    if not res_type or not res_id or not res_id.isdigit():
        return jsonify({'error': 'Invalid resource parameters'}), 400
    
    from system.database import get_resource_schedule_details
    details = get_resource_schedule_details(res_type, int(res_id))
    if not details:
        return jsonify({'error': 'Resource not found'}), 404
    return jsonify(details)


@app.route("/api/sister_sections", methods=["GET"])
def get_sister_sections():
    """
    PURPOSE: Retrieves sister sections sharing the same subject or content group to coordinate synchronized slot changes.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard:
        return jsonify({'error': 'Not authorised'}), 403
    exam_id = request.args.get('exam_id', type=int)
    from system.database import open_db
    db = open_db()
    if not db:
        return jsonify({'sections': []})
    try:
        c = db.cursor(dictionary=True)
        c.execute("SELECT subject_name FROM exams WHERE id=%s", (exam_id,))
        ex = c.fetchone()
        if not ex or not ex.get('subject_name'): return jsonify({'sections': []})
        # All sections taking this exam (including the one being edited)
        c.execute("""
            SELECT e.id, e.subject_name, e.section, e.room_id, e.instructor_id, e.exam_date_time,
                   r.room_name, i.name AS instructor_name
            FROM exams e
            LEFT JOIN rooms r       ON r.id = e.room_id
            LEFT JOIN instructors i ON i.id = e.instructor_id
            WHERE UPPER(REPLACE(e.subject_name,' ',''))=UPPER(REPLACE(%s,' ',''))
            ORDER BY e.section
        """, (ex['subject_name'],))
        rows = c.fetchall()
        for r in rows:
            r['is_current'] = (r['id'] == exam_id)
            dt = r.get('exam_date_time')
            r['exam_date_time'] = dt.strftime('%b %d, %Y %I:%M %p') if dt else None
        return jsonify({'sections': rows})
    finally:
        db.close()

@app.route("/check_edit_conflict", methods=["POST"])
def check_edit_conflict():
    """
    PURPOSE: Validates a proposed manual exam schedule adjustment against room, proctor, and section constraints prior to saving.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard:
        return jsonify({'conflicts': ['Not authorised.']}), 403
    data         = request.get_json(force=True)
    exam_id      = int(data.get('exam_id', 0))
    new_room_id  = int(data.get('room_id', 0))
    new_inst_id  = int(data.get('instructor_id', 0))
    new_dt_str   = data.get('exam_datetime', '')
    duration     = int(data.get('duration_minutes', 60))
    conflicts    = check_edit_conflicts(exam_id, new_room_id, new_inst_id, new_dt_str, duration)
    return jsonify({'conflicts': conflicts})

@app.route("/edit_exam_schedule/<int:exam_id>", methods=["POST"])
def edit_exam_schedule(exam_id):
    """
    PURPOSE: Commits manual timetable edits (date, time, room, proctor) for an individual or synchronized group of exams.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    new_room_id  = int(request.form.get('room_id', 0))
    new_inst_id  = int(request.form.get('instructor_id', 0))
    new_dt_str   = request.form.get('exam_datetime', '')
    duration     = int(float(request.form.get('duration_hours', 1)) * 60)
    force        = request.form.get('force_save') == '1'
    sync_all     = request.form.get('sync_all_sections') in ['on', '1']
    
    if not force:
        conflicts = check_edit_conflicts(exam_id, new_room_id, new_inst_id, new_dt_str, duration)
        if conflicts:
            flash('Edit blocked: ' + ' | '.join(conflicts), 'danger')
            return redirect(url_for('schedule_view'))
    ok = apply_exam_edit(exam_id, new_room_id, new_inst_id, new_dt_str, sync_all=sync_all, form_data=request.form)
    if ok:
        log_audit_event('EXAM_SCHEDULE_MANUAL_OVERRIDE',
            f"Admin {session.get('full_name')} manually edited exam #{exam_id} schedule: Datetime='{new_dt_str}', RoomID={new_room_id}, ProctorID={new_inst_id}, SyncAll={sync_all}.",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role=session.get('role'),
            ip_address=request.remote_addr
        )
        flash('Exam schedule updated.', 'success')
        # Only send email if schedule is already live/published (never spam during draft edits)
        try:
            if is_schedule_published():
                exam = get_exam_by_id(exam_id)
                if exam and exam.get('instructor_id'):
                    db = open_db()
                    if db:
                        c = db.cursor(dictionary=True)
                        c.execute("SELECT u.email, u.full_name FROM users u WHERE u.instructor_id = %s AND u.role='proctor'",
                                  (exam['instructor_id'],))
                        row = c.fetchone()
                        db.close()
                        if row and row.get('email'):
                            dt_str = new_dt_str.replace('T', ' ')
                            send_email_notification(
                                row['email'],
                                f"CCA Exam Schedule Updated â€” {exam['subject_name']}",
                                f"Dear {row['full_name']},\n\nYour proctoring assignment has been updated:\n"
                                f"Subject: {exam['subject_name']}\nNew Date/Time: {dt_str}\n\n"
                                f"CCA Exam Management System"
                            )
        except Exception as e:
            print(f"[Edit email error] {e}")
    else:
        flash('Failed to save changes.', 'danger')
    return redirect(url_for('schedule_view'))


# ==============================================================================
# SECTION 09: INSTITUTES & ACADEMIC UNITS
# ==============================================================================

@app.route("/institutes")
def institutes_page():
    """
    PURPOSE: Displays academic institutes and departments management dashboard.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    institutes = get_all_institutes()
    unread     = _get_unread(session['user_id'])
    return render_template("institutes.html", institutes=institutes, unread_count=unread)

@app.route("/institutes/add", methods=["POST"])
def add_institute_route():
    """
    PURPOSE: Creates a new academic institute / department record.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    name = request.form.get("name", "").strip()
    code = request.form.get("code", "").upper().strip()
    
    existing = get_all_institutes()
    if any(i['name'].lower() == name.lower() or i['code'].upper() == code for i in existing):
        flash(f"Warning: Institute name '{name}' or code '{code}' already exists.", "error")
        return redirect(url_for('institutes_page'))

    err = add_institute(
        name,
        request.form.get("code", "").upper(),
        request.form.get("capacity_default", 50)
    )
    if err:
        flash("An error occurred while adding the institute.", "danger")
    else:
        flash("Institute added.", "success")
    return redirect(url_for('institutes_page'))

@app.route("/institutes/<int:id>/edit", methods=["POST"])
def edit_institute_route(id):
    """
    PURPOSE: Updates institute name, code, or default exam capacity.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    edit_institute(id,
        request.form.get("name"),
        request.form.get("code", "").upper(),
        request.form.get("capacity_default", 50)
    )
    flash("Institute updated.", "success")
    return redirect(url_for('institutes_page'))

@app.route("/institutes/<int:id>/delete", methods=["POST"])
def delete_institute_route(id):
    """
    PURPOSE: Deletes an academic institute from the system.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    err = delete_institute(id)
    if err:
        flash("Cannot delete institute. Please verify no courses or faculty are assigned to it.", "danger")
    else:
        flash("Institute deleted.", "success")
    return redirect(url_for('institutes_page'))

# ==============================================================================
# SECTION 10: SUBJECTS & CONTENT GROUPS
# ==============================================================================

@app.route("/subjects/link_content", methods=["POST"])
def link_content_route():
    """
    PURPOSE: Groups multiple course sections under a unified Content Group for synchronized multi-room examinations.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    raw_ids = request.form.getlist("subject_ids")
    ids = []
    for v in raw_ids:
        # Support comma-separated values as well as multiple form fields
        for part in v.split(','):
            part = part.strip()
            if part.isdigit():
                ids.append(int(part))
    # Deduplicate while preserving order
    seen = set()
    unique_ids = []
    for i in ids:
        if i not in seen:
            seen.add(i)
            unique_ids.append(i)
    if len(unique_ids) < 2:
        flash("Select at least two different subjects to link.", "warning")
        return redirect(url_for('subjects_page'))
    # Link all selected subjects into one group by chaining pairwise links
    for i in range(1, len(unique_ids)):
        link_subjects_content_group(unique_ids[0], unique_ids[i])
    clash_sec = check_subjects_section_overlap(unique_ids)
    if clash_sec:
        flash(f"{len(unique_ids)} subjects linked. Note: Section '{clash_sec}' is enrolled in multiple of these subjects. To prevent student exam collisions, overlapping subjects will be placed into separate time slots.", "info")
    else:
        flash(f"{len(unique_ids)} subjects linked as identical content (will be scheduled simultaneously in the same slot).", "success")
    return redirect(url_for('subjects_page'))

@app.route("/subjects/<int:id>/unlink")
def unlink_subject_route(id):
    """
    PURPOSE: Removes a subject or section from its assigned Content Group.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    unlink_subject_content_group(id)
    flash("Subject removed from its content group.", "success")
    return redirect(url_for('subjects_page'))

@app.route("/subjects")
def subjects_page():
    """
    PURPOSE: Curates subject catalog, course codes, classifications (Major vs Minor), and Content Group memberships.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    subjects       = get_all_subjects()
    institutes     = get_all_institutes()
    content_groups = get_subject_content_groups()
    unread         = _get_unread(session['user_id'])
    return render_template("subjects.html",
                           subjects=subjects, institutes=institutes,
                           content_groups=content_groups, unread_count=unread)

@app.route("/subjects/add", methods=["POST"])
def add_subject_route():
    """
    PURPOSE: Adds a new course subject with credit units, department, and examination duration.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    name = request.form.get("name", "").strip()
    code = request.form.get("code", "").strip()
    
    existing = get_all_subjects()
    if any(s['code'].lower() == code.lower() for s in existing if s.get('code')):
        flash(f"Warning: Subject code '{code}' already exists.", "error")
        return redirect(url_for('subjects_page'))
        
    add_subject(
        name,
        request.form.get("code", ""),
        request.form.get("institute_id") or None,
        1 if request.form.get("is_common") else 0,
        request.form.get("content_group_id") or None
    )
    flash("Subject added.", "success")
    return redirect(url_for('subjects_page'))

@app.route("/subjects/<int:id>/edit", methods=["POST"])
def edit_subject_route(id):
    """
    PURPOSE: Modifies subject metadata, department assignment, or classification.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    edit_subject(id,
        request.form.get("name"),
        request.form.get("code", ""),
        request.form.get("institute_id") or None,
        1 if request.form.get("is_common") else 0,
        request.form.get("content_group_id") or None
    )
    flash("Subject updated.", "success")
    return redirect(url_for('subjects_page'))

@app.route("/subjects/<int:id>/delete", methods=["POST"])
def delete_subject_route(id):
    """
    PURPOSE: Deletes an individual subject from the academic catalog.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    err = delete_subject(id)
    if err:
        flash("Cannot delete subject. Please verify no active exams are assigned to it.", "danger")
    else:
        flash("Subject deleted.", "success")
    return redirect(url_for('subjects_page'))


@app.route("/subjects/bulk_delete", methods=["POST"])
def bulk_delete_subjects():
    """
    PURPOSE: Performs bulk deletion of multiple selected subjects.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    ids = request.form.getlist('subject_ids')
    if not ids:
        flash("No subjects selected.", "warning")
        return redirect(url_for('subjects_page'))
    deleted, errors = 0, []
    for sid in ids:
        try:
            err = delete_subject(int(sid))
            if err:
                errors.append(err)
            else:
                deleted += 1
        except Exception as e:
            errors.append(str(e))
    if deleted:
        flash(f" {deleted} subject(s) deleted successfully.", "success")
    if errors:
        flash(f" {len(errors)} subject(s) could not be deleted: " + "; ".join(errors), "warning")
    return redirect(url_for('subjects_page'))


@app.route("/subjects/import", methods=["POST"])
def import_subjects_route():
    """
    PURPOSE: Handles bulk CSV/Excel import of subjects into the course catalog.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    f = request.files.get("csv_file")
    if not f:
        flash("No file uploaded.", "danger")
        return redirect(url_for('subjects_page'))
    from system.importer import parse_subjects_csv
    rows, parse_errors = parse_subjects_csv(f.read())
    institutes = {i['code'].upper(): i['id'] for i in get_all_institutes() if i and i.get('code')}
    for r in rows:
        code = r.get('institute_code', '').upper()
        r['institute_id'] = institutes.get(code)
    ok, errors = bulk_import_subjects(rows)
    if parse_errors:
        flash(f"Parse errors: {'; '.join(parse_errors)}", "warning")
    flash(f"Imported {ok} subject(s). {len(errors)} error(s).", "success" if not errors else "warning")
    return redirect(url_for('subjects_page'))

# ==============================================================================
# SECTION 11: FACULTY & PROCTOR MANAGEMENT
# ==============================================================================

@app.route("/faculty")
def faculty_page():
    """
    PURPOSE: Faculty management console tracking instructor profiles, proctor hours, and availability.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    instructors    = get_all_instructors()
    institutes     = get_all_institutes()
    subjects       = get_all_subjects()
    period_summary = get_all_proctor_hours_summary()
    unread         = _get_unread(session['user_id'])
    
    period_start, period_end = get_exam_period()
    exam_start = period_start.strftime('%Y-%m-%d') if period_start else ''
    exam_end   = period_end.strftime('%Y-%m-%d') if period_end else ''
    
    return render_template("faculty.html",
                           instructors=instructors, institutes=institutes,
                           subjects=subjects, period_summary=period_summary,
                           buildings=get_all_buildings(),
                           unread_count=unread,
                           exam_start=exam_start, exam_end=exam_end)

@app.route("/faculty/<int:id>/edit", methods=["POST"])
@app.route("/edit_instructor/<int:id>", methods=["POST"])
def faculty_edit(id):
    """
    PURPOSE: Updates faculty information including department, PWD status, and taught subjects.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    
    last = request.form.get("last_name", "").strip()
    first = request.form.get("first_name", "").strip()
    middle = request.form.get("middle_name", "").strip()
    suffix = request.form.get("suffix", "").strip()
    
    if last and first:
        full_name = f"{last}, {first}"
        if middle:
            full_name += f" {middle[0]}." if len(middle) == 1 else f" {middle}"
        if suffix:
            full_name += f" {suffix}"
    else:
        full_name = request.form.get("name", "").strip()
        
    building = request.form.get("building", "").strip()
    if building == '__new__':
        building = request.form.get("new_building_name", "").strip() or "Main Building"

    edit_instructor(id,
        full_name,
        (int(request.form.get("institute_id")) if request.form.get("institute_id") and request.form.get("institute_id").strip().isdigit() and int(request.form.get("institute_id")) > 0 else None),
        building,
        1 if request.form.get("is_pwd") else 0,
        request.form.get("subjects_taught", "")
    )
    flash("Instructor updated.", "success")
    ref = request.referrer or ''
    if 'dashboard' in ref:
        return redirect(url_for('dashboard') + '#instructors')
    return redirect(url_for('faculty_page'))

@app.route("/faculty/<int:id>/deactivate", methods=["POST"])
@app.route("/deactivate_instructor/<int:id>", methods=["POST"])
def faculty_deactivate(id):
    """
    PURPOSE: Sets faculty member to inactive, removing them from proctor assignment pools.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    deactivate_instructor(id)
    flash("Instructor deactivated.", "warning")
    ref = request.referrer or ''
    if 'dashboard' in ref:
        return redirect(url_for('dashboard') + '#instructors')
    return redirect(url_for('faculty_page'))

@app.route("/faculty/<int:id>/activate", methods=["POST"])
@app.route("/activate_instructor/<int:id>", methods=["POST"])
def faculty_activate(id):
    """
    PURPOSE: Restores inactive faculty member to active proctoring eligibility.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    activate_instructor(id)
    flash("Instructor activated.", "success")
    ref = request.referrer or ''
    if 'dashboard' in ref:
        return redirect(url_for('dashboard') + '#instructors')
    return redirect(url_for('faculty_page'))

@app.route("/admin/proctor_availability/<int:id>", methods=["GET", "POST"])
def admin_proctor_availability(id):
    """
    PURPOSE: Administrative interface for viewing and manually updating specific proctor availability windows.
    ACCESS:  Admin, Super Admin
    METHOD:  GET, POST
    """
    guard = require_role('admin')
    if guard: return guard
    
    # Get instructor info
    db = open_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT i.*, inst.name as institute_name,
               (SELECT ROUND(COALESCE(SUM(duration_minutes)/60.0, 0), 1) FROM exams WHERE instructor_id = i.id AND status = 'Scheduled') as total_hours
        FROM instructors i LEFT JOIN institutes inst ON i.institute_id = inst.id WHERE i.id = %s
    """, (id,))
    instructor = cursor.fetchone()
    db.close()
    if instructor and instructor.get('total_hours') is not None:
        tot = float(instructor['total_hours'])
        instructor['total_hours'] = int(tot) if tot.is_integer() else round(tot, 1)
    
    if not instructor:
        flash("Instructor not found.", "danger")
        return redirect(url_for('faculty_page'))
        
    if request.method == "POST":
        dates       = request.form.getlist("available_dates")
        start_times = request.form.getlist("start_times")
        end_times   = request.form.getlist("end_times")
        entries = []
        for i, d in enumerate(dates):
            d_str = str(d).strip()
            if not d_str: continue
            st = start_times[i].strip() if i < len(start_times) and start_times[i].strip() else '07:00'
            et = end_times[i].strip() if i < len(end_times) and end_times[i].strip() else '20:00'
            entries.append({'date': d_str, 'start_time': st, 'end_time': et})
            
        save_proctor_availability(id, entries)
        
        # Check if also applying to additional instructors
        also_apply_ids = request.form.getlist("also_apply_ids")
        if request.form.get("apply_to_same_dept") == "1" and instructor.get('institute_id'):
            db = open_db()
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT id FROM instructors WHERE institute_id = %s AND id != %s AND status = 'Active'", (instructor['institute_id'], id))
            dept_insts = cursor.fetchall()
            db.close()
            also_apply_ids.extend([str(r['id']) for r in dept_insts])
            
        if also_apply_ids:
            unique_extra_ids = list(set([i for i in also_apply_ids if str(i) != str(id)]))
            if unique_extra_ids:
                bulk_save_proctor_availability(unique_extra_ids, entries, mode='replace')
                flash(f"Availability saved for {instructor['name']} and {len(unique_extra_ids)} other instructor(s).", "success")
            else:
                flash(f"Availability saved for {instructor['name']}.", "success")
        else:
            flash(f"Availability saved for {instructor['name']}.", "success")
            
        return redirect(url_for('faculty_page'))

    saved_dates = get_proctor_availability_for(id)
    period_start, period_end = get_exam_period()
    exam_start = period_start.strftime('%Y-%m-%d') if period_start else ''
    exam_end   = period_end.strftime('%Y-%m-%d') if period_end else ''
    
    all_instructors = get_all_instructors()
    same_dept_instructors = [
        ins for ins in all_instructors 
        if ins['id'] != id and ins.get('institute_id') == instructor.get('institute_id') and ins.get('status') == 'Active'
    ]
    
    return render_template("admin_availability.html", 
                           instructor=instructor, 
                           saved_dates=saved_dates,
                           exam_start=exam_start,
                           exam_end=exam_end,
                           same_dept_instructors=same_dept_instructors,
                           all_instructors=[ins for ins in all_instructors if ins['id'] != id and ins.get('status') == 'Active'])

@app.route("/admin/bulk_proctor_availability", methods=["POST"])
def admin_bulk_proctor_availability():
    """
    PURPOSE: Bulk saves availability time blocks for multiple proctors simultaneously.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    
    instructor_ids = request.form.getlist("instructor_ids")
    if not instructor_ids:
        raw_ids = request.form.get("instructor_ids_csv", "")
        if raw_ids:
            instructor_ids = [i.strip() for i in raw_ids.split(",") if i.strip()]
            
    if not instructor_ids:
        flash("No instructors selected for availability update.", "warning")
        return redirect(url_for('faculty_page'))
        
    dates       = request.form.getlist("available_dates")
    start_times = request.form.getlist("start_times")
    end_times   = request.form.getlist("end_times")
    mode        = request.form.get("availability_mode", "replace") # 'replace' or 'append'
    
    entries = []
    for i, d in enumerate(dates):
        d_str = str(d).strip()
        if not d_str: continue
        st = start_times[i].strip() if i < len(start_times) and start_times[i].strip() else '07:00'
        et = end_times[i].strip() if i < len(end_times) and end_times[i].strip() else '20:00'
        entries.append({'date': d_str, 'start_time': st, 'end_time': et})
        
    bulk_save_proctor_availability(instructor_ids, entries, mode=mode)
    action_desc = "appended to" if mode == "append" else "set for"
    flash(f"Availability successfully {action_desc} {len(instructor_ids)} selected instructor(s).", "success")
    return redirect(url_for('faculty_page'))

# ==============================================================================
# SECTION 12: BULK DATA IMPORT WORKFLOWS (CSV / EXCEL)
# ==============================================================================

@app.route("/import/rooms", methods=["POST"])
def import_rooms():
    """
    PURPOSE: Bulk imports classroom and lab inventory from uploaded CSV or Excel files.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    f = request.files.get("csv_file")
    if not f:
        flash("No file uploaded.", "danger")
        return redirect(url_for('dashboard') + '#rooms')
    from system.importer import parse_rooms_csv
    rows, parse_errors = parse_rooms_csv(f.read())
    institutes = {i['code'].upper(): i['id'] for i in get_all_institutes() if i and i.get('code')}
    for r in rows:
        code = r.pop('institute_code', '').upper()
        r['institute_id'] = institutes.get(code)
    ok, errors = bulk_import_rooms(rows)
    if parse_errors:
        flash(f"Parse warnings: {'; '.join(parse_errors)}", "warning")
    flash(f"Imported {ok} room(s). {len(errors)} skipped.", "success" if not errors else "warning")
    return redirect(url_for('dashboard') + '#rooms')

@app.route("/import/instructors", methods=["POST"])
def import_instructors():
    """
    PURPOSE: Bulk imports faculty profiles and teaching assignments from uploaded CSV/Excel files.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    f = request.files.get("csv_file")
    if not f:
        flash("No file uploaded.", "danger")
        return redirect(url_for('dashboard') + '#instructors')
    from system.importer import parse_instructors_csv
    rows, parse_errors = parse_instructors_csv(f.read())
    institutes = {i['code'].upper(): i['id'] for i in get_all_institutes() if i and i.get('code')}
    for r in rows:
        code = r.pop('institute_code', '').upper()
        r['institute_id'] = institutes.get(code)
    ok, errors = bulk_import_instructors(rows)
    if parse_errors:
        flash(f"Parse warnings: {'; '.join(parse_errors)}", "warning")
    flash(f"Imported {ok} instructor(s). {len(errors)} skipped.", "success" if not errors else "warning")
    return redirect(url_for('dashboard') + '#instructors')

@app.route("/import/exams", methods=["POST"])
def import_exams():
    """
    PURPOSE: Bulk imports course exam requests and section allocations from CSV/Excel files.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    f = request.files.get("csv_file")
    if not f:
        flash("No file uploaded.", "danger")
        return redirect(url_for('dashboard') + '#exams')
    from system.importer import parse_exams_csv
    rows, parse_errors = parse_exams_csv(f.read())
    institutes = {i['code'].upper().strip(): i['id'] for i in get_all_institutes() if i and i.get('code')}
    all_subs = get_all_subjects()
    subjects_by_code = {s['code'].upper().strip(): s for s in all_subs if s and s.get('code')}
    subjects_by_name = {s['name'].upper().strip(): s for s in all_subs if s and s.get('name')}
    
    new_subjects_created = 0
    db_conn = open_db()
    try:
        c_cur = db_conn.cursor(dictionary=True) if db_conn else None
        for r in rows:
            inst_code = (r.pop('institute_code', '') or '').upper().strip()
            r['institute_id'] = institutes.get(inst_code)
            
            subj_code = (r.pop('subject_code', '') or '').strip()
            subj_name = (r.get('subject_name', '') or subj_code).strip()
            
            # 1. Match by code or by name (case-insensitive)
            subj = None
            if subj_code:
                subj = subjects_by_code.get(subj_code.upper())
            if not subj and subj_name:
                subj = subjects_by_name.get(subj_name.upper())
            if not subj and subj_code:
                subj = subjects_by_name.get(subj_code.upper())
                
            # 2. If subject doesn't exist yet, auto-create it so it immediately reflects in Subject Management!
            if not subj and (subj_name or subj_code) and c_cur:
                c_name = subj_name or subj_code
                c_code = subj_code or c_name
                c_cur.execute(
                    "INSERT INTO subjects (name, code, institute_id, is_common, content_group_id) VALUES (%s, %s, %s, 0, NULL)",
                    (c_name, c_code, r.get('institute_id'))
                )
                new_id = c_cur.lastrowid
                subj = {'id': new_id, 'name': c_name, 'code': c_code}
                new_subjects_created += 1
                if c_code: subjects_by_code[c_code.upper()] = subj
                if c_name: subjects_by_name[c_name.upper()] = subj
            
            if subj:
                r['subject_id'] = subj['id']
                r['subject_name'] = subj['name']
            else:
                r['subject_id'] = None
                r['subject_name'] = subj_name or subj_code
        if db_conn:
            db_conn.commit()
    finally:
        if db_conn:
            db_conn.close()

    ok, errors = bulk_import_exams(rows)
    sync_exam_and_subject_institutes()
    msg = f"Imported {ok} exam(s)."
    if new_subjects_created > 0:
        msg += f" {new_subjects_created} new subject(s) automatically added to Subject Management."
    if errors:
        msg += f" {len(errors)} exam(s) skipped."
    flash(msg, "success" if not errors else "warning")
    if parse_errors:
        flash(f"Parse warnings: {'; '.join(parse_errors)}", "warning")
    return redirect(url_for('dashboard') + '#exams')

@app.route("/exams/bulk_delete", methods=["POST"])
def bulk_delete_exams_route():
    """
    PURPOSE: Bulk deletes multiple selected examination requests.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    ids = request.form.getlist('exam_ids')
    if not ids:
        flash("No exams selected.", "warning")
        return redirect(url_for('dashboard') + '#exams')
    deleted, errors = bulk_delete_exams(ids)
    if deleted:
        flash(f"Deleted {deleted} exam(s) successfully.", "success")
    if errors:
        flash(f"{len(errors)} exam(s) could not be deleted.", "warning")
    return redirect(url_for('dashboard') + '#exams')

# ==============================================================================
# SECTION 13: DATA EXPORT & AUDIT REPORTING (PDF & CSV)
# ==============================================================================

@app.route("/export/schedule.pdf")
def export_schedule_pdf():
    """
    PURPOSE: Generates and streams official Master Exam Timetable PDF report.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    from system.exporter import export_schedule_pdf as _pdf
    all_exams = get_schedule_results()
    scheduled_exams = [e for e in all_exams if e['status'] == 'Scheduled']
    # Build conflict_ids
    conflict_ids = set()
    for i, a in enumerate(scheduled_exams):
        dt_a = a['exam_date_time']
        if isinstance(dt_a, str):
            dt_a = datetime.strptime(dt_a, "%Y-%m-%d %H:%M:%S")
        end_a = dt_a + timedelta(minutes=a['duration_minutes'] or 60)
        for b in scheduled_exams[i+1:]:
            dt_b = b['exam_date_time']
            if isinstance(dt_b, str):
                dt_b = datetime.strptime(dt_b, "%Y-%m-%d %H:%M:%S")
            end_b = dt_b + timedelta(minutes=b['duration_minutes'] or 60)
            if dt_a < end_b and dt_b < end_a and a.get('room_id') == b.get('room_id'):
                conflict_ids.add(a['id']); conflict_ids.add(b['id'])
    # Group by date
    grouped = defaultdict(list)
    for exam in scheduled_exams:
        dt = exam['exam_date_time']
        if isinstance(dt, str):
            dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
        grouped[dt.strftime("%A, %B %d, %Y")].append(exam)
    sorted_groups = sorted(grouped.items(),
                           key=lambda x: datetime.strptime(x[0], "%A, %B %d, %Y"))
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    prepared_by = session.get('full_name', 'Administrator')
    pdf_bytes = _pdf(sorted_groups, conflict_ids, exam_term=exam_term, exam_semester=exam_semester, prepared_by=prepared_by)
    return send_file(io.BytesIO(pdf_bytes), mimetype='application/pdf',
                     as_attachment=True, download_name='exam_schedule.pdf')

@app.route("/export/absence_report.pdf")
def export_absence_pdf():
    """
    PURPOSE: Generates and exports PDF audit report of recorded proctor absences and relief assignments.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin', 'secretary')
    if guard: return guard
    from system.exporter import export_proctor_report_pdf
    date_from = request.args.get('from', '')
    date_to   = request.args.get('to', '')
    absence   = get_proctor_absence_report(date_from or None, date_to or None)
    hours     = get_all_proctor_hours_summary()
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    prepared_by = session.get('full_name', 'Administrator')
    pdf_bytes = export_proctor_report_pdf(hours, absence, exam_term=exam_term, exam_semester=exam_semester, prepared_by=prepared_by, report_type='absence')
    return send_file(io.BytesIO(pdf_bytes), mimetype='application/pdf',
                     as_attachment=True, download_name='proctor_absence_report.pdf')

@app.route("/export/assignment_report.pdf")
def export_assignment_pdf():
    """
    PURPOSE: Generates comprehensive Proctor Assignment Workload Summary PDF report.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin', 'secretary')
    if guard: return guard
    from system.exporter import export_proctor_report_pdf
    hours   = get_all_proctor_hours_summary()
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    prepared_by = session.get('full_name', 'Administrator')
    pdf_bytes = export_proctor_report_pdf(hours, [], exam_term=exam_term, exam_semester=exam_semester, prepared_by=prepared_by, report_type='assignment')
    return send_file(io.BytesIO(pdf_bytes), mimetype='application/pdf',
                     as_attachment=True, download_name='proctor_assignment_report.pdf')

@app.route("/export/collection_report.pdf")
def export_collection_pdf():
    """
    PURPOSE: Generates Secretary Exam Material Handout and Return status audit PDF.
    ACCESS:  Admin, Super Admin, Secretary
    METHOD:  GET
    """
    guard = require_role('admin', 'secretary')
    if guard: return guard
    from system.exporter import export_collection_report_pdf
    data = get_exam_collection_status()
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    prepared_by = session.get('full_name', 'Administrator')
    pdf_bytes = export_collection_report_pdf(data, exam_term=exam_term, exam_semester=exam_semester, prepared_by=prepared_by)
    return send_file(io.BytesIO(pdf_bytes), mimetype='application/pdf',
                     as_attachment=True, download_name='collection_report.pdf')

# ── REPORTS ─────────────────────────────────────────────────────────────────

@app.route("/reports/clear_absence", methods=["POST"])
def clear_absence_reports_route():
    """
    PURPOSE: Clears historical proctor absence records after academic review.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    clear_absence_reports()
    log_audit_event('ABSENCE_REPORTS_CLEARED',
        f"Admin {session.get('full_name')} cleared proctor duty absence records.",
        user_id=session.get('user_id'),
        user_name=session.get('full_name'),
        user_role=session.get('role'),
        ip_address=request.remote_addr
    )
    flash("Proctor absence reports cleared.", "success")
    return redirect(url_for('reports_page'))

@app.route("/reports")
def reports_page():
    """
    PURPOSE: Central reporting portal summarizing scheduling completeness, proctor load, and student exam distribution.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin', 'secretary')
    if guard: return guard
    date_from = request.args.get('from', '')
    date_to   = request.args.get('to', '')
    active_tab = request.args.get('tab', '')
    absence   = get_proctor_absence_report(date_from or None, date_to or None)
    assignment = get_assignment_report()
    scheduling = get_scheduling_report(date_from or None, date_to or None)
    unread     = _get_unread(session['user_id'])

    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    prepared_by = session.get('full_name', 'Administrator')
    prepared_by_role = session.get('role', 'admin').capitalize()
    from datetime import datetime
    generated_at = datetime.now().strftime("%B %d, %Y %I:%M %p")

    return render_template("reports.html",
                           absence_report=absence,
                           assignment_report=assignment,
                           scheduling_report=scheduling,
                           date_from=date_from, date_to=date_to,
                           active_tab=active_tab,
                           exam_term=exam_term,
                           exam_semester=exam_semester,
                           prepared_by=prepared_by,
                           prepared_by_role=prepared_by_role,
                           generated_at=generated_at,
                           unread_count=unread)

# ── EXAM ARCHIVES (HISTORICAL RECORDS) ──────────────────────────────────────

@app.route("/admin/archives")
def admin_archives():
    """
    PURPOSE: Manages historical snapshots of previous exam periods and semesters for institutional compliance.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin', 'secretary')
    if guard: return guard
    archives = get_exam_archives()
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    unread = _get_unread(session['user_id'])
    return render_template("archives.html",
                           archives=archives,
                           current_term=exam_term,
                           current_semester=exam_semester,
                           unread_count=unread)

@app.route("/admin/archives/create", methods=["POST"])
def admin_archives_create():
    """
    PURPOSE: Creates an immutable archived snapshot of the current exam timetable before term reset.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    academic_year = request.form.get("academic_year", "2025-2026").strip()
    exam_term = request.form.get("exam_term", "Midterm").strip()
    exam_semester = request.form.get("exam_semester", "1st Semester").strip()
    archive_title = request.form.get("archive_title", "").strip()
    notes = request.form.get("notes", "").strip()

    ok, res = create_exam_archive(
        academic_year=academic_year,
        exam_term=exam_term,
        exam_semester=exam_semester,
        archive_title=archive_title or None,
        notes=notes or None,
        user_id=session.get('user_id'),
        user_name=session.get('full_name')
    )
    if ok:
        flash(f"Successfully created historical archive '{archive_title or f'A.Y. {academic_year} {exam_semester} {exam_term}'}'.", "success")
    else:
        flash(f"Failed to create archive: {res}", "danger")
    return redirect(url_for('admin_archives'))

@app.route("/admin/archives/<int:archive_id>")
def admin_archive_view(archive_id):
    """
    PURPOSE: Displays read-only view of a saved historical examination archive.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin', 'secretary')
    if guard: return guard
    archive = get_exam_archive_by_id(archive_id)
    if not archive:
        flash("Archived record not found.", "danger")
        return redirect(url_for('admin_archives'))
    unread = _get_unread(session['user_id'])
    settings = get_system_settings() or {}
    return render_template("archive_view.html",
                           archive=archive,
                           settings=settings,
                           unread_count=unread)

@app.route("/admin/archives/<int:archive_id>/sync_durations", methods=["POST"])
def admin_archive_sync_durations(archive_id):
    """
    PURPOSE: Utility aligning exam duration values across historical archive records.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    ok, msg = sync_archive_durations(archive_id)
    if ok:
        flash("Archive durations and end times successfully synchronized with current settings.", "success")
    else:
        flash(f"Failed to sync archive durations: {msg}", "danger")
    return redirect(url_for('admin_archive_view', archive_id=archive_id))

@app.route("/admin/archives/<int:archive_id>/export_csv")
def admin_archive_export_csv(archive_id):
    """
    PURPOSE: Exports archive records into formatted CSV spreadsheet.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin', 'secretary')
    if guard: return guard
    archive = get_exam_archive_by_id(archive_id)
    if not archive:
        flash("Archived record not found.", "danger")
        return redirect(url_for('admin_archives'))

    import csv
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Subject Name", "Subject Code", "Section", "Subject Type",
        "Exam Date", "Start Time", "End Time", "Duration (min)",
        "Room", "Building", "Floor", "Proctor", "Institute"
    ])
    for ex in archive.get('exams', []):
        writer.writerow([
            ex.get('subject_name', ''),
            ex.get('subject_code', ''),
            ex.get('section', ''),
            ex.get('subject_type', ''),
            ex.get('formatted_date') or (ex.get('exam_date_time')[:10] if ex.get('exam_date_time') else ''),
            ex.get('formatted_time', ''),
            ex.get('formatted_time_end', ''),
            ex.get('duration_minutes', 60),
            ex.get('room_name', ''),
            ex.get('building', ''),
            ex.get('floor', ''),
            ex.get('instructor_name', ''),
            ex.get('institute_name', '')
        ])

    csv_data = output.getvalue()
    safe_title = "".join(c for c in archive.get('archive_title', 'archive') if c.isalnum() or c in (' ', '_', '-')).strip().replace(' ', '_')
    filename = f"{safe_title}.csv"
    response = make_response(csv_data)
    response.headers["Content-Disposition"] = f"attachment; filename={filename}"
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    return response

@app.route("/admin/archives/<int:archive_id>/export_pdf")
def admin_archive_export_pdf(archive_id):
    """
    PURPOSE: Generates official PDF document of an archived examination timetable snapshot.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin', 'secretary')
    if guard: return guard
    archive = get_exam_archive_by_id(archive_id)
    if not archive:
        flash("Archived record not found.", "danger")
        return redirect(url_for('admin_archives'))

    from system.exporter import export_archive_pdf
    pdf_bytes = export_archive_pdf(archive)
    safe_title = "".join(c for c in archive.get('archive_title', 'archive') if c.isalnum() or c in (' ', '_', '-')).strip().replace(' ', '_')
    filename = f"{safe_title}.pdf"
    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype='application/pdf',
        as_attachment=True,
        download_name=filename
    )

@app.route("/admin/archives/<int:archive_id>/delete", methods=["POST"])
def admin_archive_delete(archive_id):
    """
    PURPOSE: Permanently removes a historical archive record.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard
    archive = get_exam_archive_by_id(archive_id)
    archive_title = archive.get('archive_title', f"#{archive_id}") if archive else f"#{archive_id}"
    ok, msg = delete_exam_archive(archive_id)
    if ok:
        log_audit_event(
            'ARCHIVE_DELETED',
            f"Super Admin {session.get('full_name')} permanently deleted historical snapshot archive '{archive_title}' (ID #{archive_id}).",
            ip_address=request.remote_addr,
            user_id=session.get('user_id'),
            user_role=session.get('role'),
            user_name=session.get('full_name')
        )
        flash(msg, "success")
    else:
        flash(f"Error deleting archive: {msg}", "danger")
    return redirect(url_for('admin_archives'))

# ==============================================================================
# SECTION 14: SYSTEM SETTINGS & CONSTRAINT CONFIGURATION
# ==============================================================================

@app.route("/settings")
def settings_page():
    """
    PURPOSE: Displays master system settings, constraint parameters, term dates, and SMTP configuration.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    settings = get_system_settings()
    unread   = _get_unread(session['user_id'])
    return render_template("settings.html", settings=settings, unread_count=unread)

@app.route("/settings/save", methods=["POST"])
def settings_save():
    """
    PURPOSE: Saves master configuration changes (exam dates, proctor limits, daily caps, mail server).
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    
    cur_settings = get_system_settings() or {}

    def get_int(key, default):
        val = request.form.get(key, "").strip()
        if val:
            try: return int(val)
            except ValueError: pass
        return int(cur_settings.get(key, default) or default)

    def get_float(key, default):
        val = request.form.get(key, "").strip()
        if val:
            try: return float(val)
            except ValueError: pass
        return float(cur_settings.get(key, default) or default)

    save_system_settings(
        day_start=request.form.get("day_start") or cur_settings.get("day_start", "07:00"),
        day_end=request.form.get("day_end") or cur_settings.get("day_end", "20:00"),
        slot_interval_min=get_int("slot_interval_min", 60),
        max_proctor_hrs=get_int("max_consecutive_proctor_hrs", 3),
        travel_buffer_min=get_int("travel_buffer_min", 15),
        smtp_host=request.form.get("smtp_host", cur_settings.get("smtp_host", "")),
        smtp_port=get_int("smtp_port", 587),
        smtp_user=request.form.get("smtp_user", cur_settings.get("smtp_user", "")),
        smtp_password=request.form.get("smtp_password", "").strip() or cur_settings.get("smtp_password", ""),
        smtp_from=request.form.get("smtp_from", cur_settings.get("smtp_from", "")),
        smtp_use_tls=1 if request.form.get("smtp_use_tls") else cur_settings.get("smtp_use_tls", 0),
        major_duration_hrs=get_float("major_duration_hrs", 2.0),
        minor_duration_hrs=get_float("minor_duration_hrs", 1.0),
        max_daily_proctor_hrs=get_float("max_daily_proctor_hrs", 4.0)
    )
    
    # Auto-update existing exams to match the new duration defaults
    major_min = int(get_float("major_duration_hrs", 2.0) * 60)
    minor_min = int(get_float("minor_duration_hrs", 1.0) * 60)
    from system.database import open_db
    db = open_db()
    if db:
        try:
            cur = db.cursor()
            cur.execute("UPDATE exams SET duration_minutes=%s WHERE subject_type='Major'", (major_min,))
            cur.execute("UPDATE exams SET duration_minutes=%s WHERE subject_type='Minor'", (minor_min,))
            db.commit()
        except Exception as e:
            print("Auto-update exams error:", e)
        finally:
            db.close()
            
    # Note: Historical archives are permanently preserved as immutable snapshots (Audit compliance)

    _configure_mail()
    flash("Settings saved successfully.", "success")
    return redirect(url_for('settings_page'))

@app.route("/settings/test_email", methods=["POST"])
def test_email():
    """
    PURPOSE: Sends diagnostic test email to verify SMTP and Brevo API connectivity.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    to = request.form.get("test_to", "")
    if not to:
        flash("Enter a recipient email address.", "warning")
        return redirect(url_for('settings_page'))
    try:
        s = get_system_settings()
        password = (s.get('smtp_password') or '').replace(' ', '').strip()
        brevo_key = os.environ.get('BREVO_API_KEY') or s.get('brevo_api_key')
        if not brevo_key and password.startswith('xkeysib-'):
            brevo_key = password

        if brevo_key:
            from system.mailer import send_via_brevo
            sender = s.get('smtp_from') or s.get('smtp_user') or "jpbaltazar23-0368@cca.edu.ph"
            ok, msg = send_via_brevo(brevo_key, to, "CCA Exam Management - Test Email", "This is a test email sent securely via Brevo HTTPS API (Port 443). Automated email delivery is working perfectly!", sender_email=sender)
            if ok:
                flash(f"Test email successfully sent to {to} via Brevo API!", "success")
            else:
                flash(f"Brevo API error: {msg}", "danger")
            return redirect(url_for('settings_page'))

        # Standard SMTP Test
        import smtplib
        import socket
        host = s.get('smtp_host', '')
        port = int(s.get('smtp_port') or 587)
        user = s.get('smtp_user', '')
        use_tls = bool(s.get('smtp_use_tls', 1))
        
        # Test TCP connection first
        try:
            socket.create_connection((host, port), timeout=5)
        except Exception as e:
            flash(f"Connection blocked or timed out (Port {port} might be blocked by your ISP or firewall): {e}", "danger")
            return redirect(url_for('settings_page'))
            
        # Try full SMTP handshake
        if port == 465:
            server = smtplib.SMTP_SSL(host, port, timeout=5)
            server.ehlo()
        else:
            server = smtplib.SMTP(host, port, timeout=5)
            server.ehlo()
            if use_tls:
                server.starttls()
                server.ehlo()
        server.login(user, password)
        
        # If we reach here, connection works! Send the email.
        msg = f"Subject: CCA Exam Management - Test Email\n\nThis is a test email. SMTP works!"
        server.sendmail(user, [to], msg)
        server.quit()
        
        flash(f"Test email successfully sent to {to}!", "success")
    except smtplib.SMTPAuthenticationError:
        flash("SMTP Authentication Failed. Check your App Password.", "danger")
    except Exception as e:
        flash(f"SMTP Error: {e}", "danger")
        
    return redirect(url_for('settings_page'))
    try:
        _configure_mail()
        msg = MailMessage(
            subject="CCA Exam Management â€” Test Email",
            recipients=[to],
            body="This is a test email from the CCA Exam Management System. SMTP is configured correctly."
        )
        mail.send(msg)
        flash(f"Test email sent to {to}.", "success")
    except Exception as e:
        flash(f"Failed to send email: {e}", "danger")
    return redirect(url_for('settings_page'))

# ==============================================================================
# SECTION 15: ADMINISTRATIVE PASSWORD MANAGEMENT
# ==============================================================================

@app.route("/admin/change_password/<int:user_id>", methods=["POST"])
def admin_change_password(user_id):
    """
    PURPOSE: Allows Administrator to change their own login password.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    new_password = request.form.get("new_password", "").strip()
    confirm_password = request.form.get("confirm_password", "").strip()
    redirect_to = request.form.get("redirect_to", "students_page")
    is_valid, err_msg = validate_password_strength(new_password)
    if not is_valid:
        flash(err_msg, "danger")
        return redirect(url_for(redirect_to))
    if new_password != confirm_password:
        flash("Passwords do not match.", "danger")
        return redirect(url_for(redirect_to))
    db = open_db()
    if db:
        try:
            import bcrypt as _bcrypt
            hashed = _bcrypt.hashpw(new_password.encode(), _bcrypt.gensalt()).decode()
            c = db.cursor(dictionary=True)
            c.execute("SELECT full_name, role FROM users WHERE id = %s", (user_id,))
            user = c.fetchone()
            if not user or user['role'] not in ('student', 'proctor'):
                flash("User not found or not allowed.", "danger")
                return redirect(url_for(redirect_to))
            c.execute("UPDATE users SET password = %s WHERE id = %s", (hashed, user_id))
            db.commit()
            flash(f" Password changed for {user['full_name']}.", "success")
        except Exception as e:
            flash("An error occurred while updating the password.", "danger")
        finally:
            db.close()
    return redirect(url_for(redirect_to))

def derive_user_reset_password(full_name=None):
    """
    PURPOSE: Generates a secure, cryptographically random temporary password.
    ACCESS:  Internal security helper
    """
    import secrets
    token = secrets.token_hex(4).upper()
    return f"CCA-{token[:4]}-{token[4:]}"

@app.route("/admin/reset_password/<int:user_id>", methods=["POST"])
def admin_reset_password(user_id):
    """
    PURPOSE: Allows Administrator to manually reset a student or proctor password.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    redirect_to = request.form.get("redirect_to", "students_page")
    db = open_db()
    if db:
        try:
            import bcrypt as _bcrypt
            c = db.cursor(dictionary=True)
            c.execute("SELECT full_name, role FROM users WHERE id = %s", (user_id,))
            user = c.fetchone()
            if not user or user['role'] not in ('student', 'proctor'):
                flash("User not found or not allowed.", "danger")
                return redirect(url_for(redirect_to))
            
            # Reset to custom password or generate cryptographically random temporary password
            default_pw = request.form.get("new_password", "").strip() or derive_user_reset_password(user['full_name'])
            hashed = _bcrypt.hashpw(default_pw.encode(), _bcrypt.gensalt()).decode()
            c.execute("UPDATE users SET password = %s WHERE id = %s", (hashed, user_id))
            db.commit()
            log_audit_event('USER_PASSWORD_RESET', f"Admin reset password for user ID {user_id} ({user['full_name']})", user_id=session.get('user_id'), user_name=session.get('full_name'), user_role=session.get('role'), ip_address=request.remote_addr)
            flash(f"Password for {user['full_name']} has been reset to temporary password: '{default_pw}'. Please provide this to the user.", "success")
        except Exception as e:
            flash("An error occurred while resetting password.", "danger")
        finally:
            db.close()
    return redirect(url_for(redirect_to))


# ==============================================================================
# SECTION 16: STUDENT ROSTER & ENROLLMENT MANAGEMENT
# ==============================================================================

@app.route("/students")
def students_page():
    """
    PURPOSE: Displays student enrollment roster with search, section filters, and approval queues.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    pending_students = get_pending_users()
    all_students     = get_all_students()
    institutes       = get_all_institutes()
    unread           = _get_unread(session['user_id'])
    pending_count    = len(pending_students)
    
    db_conn = open_db()
    sections = []
    if db_conn:
        try:
            cur = db_conn.cursor()
            cur.execute("SELECT DISTINCT section FROM (SELECT section FROM users WHERE section IS NOT NULL AND section != '' UNION SELECT section FROM exams WHERE section IS NOT NULL AND section != '') AS s ORDER BY section")
            sections = [r[0] for r in cur.fetchall()]
        finally:
            db_conn.close()

    return render_template("students.html",
                           pending_students=pending_students,
                           all_students=all_students,
                           institutes=institutes,
                           unread_count=unread,
                           pending_count=pending_count,
                           sections=sections)

@app.route("/admin/edit_student/<int:user_id>", methods=["POST"])
def admin_edit_student(user_id):
    """
    PURPOSE: Modifies student profile details including student number, institute, and section.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    new_section = request.form.get("section", "").strip()
    new_name = request.form.get("full_name", "").strip()
    new_email = request.form.get("email", "").strip()
    redirect_to = request.form.get("redirect_to", "students_page")
    
    db = open_db()
    if db:
        try:
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT id, full_name FROM users WHERE id = %s AND role = 'student'", (user_id,))
            student = cursor.fetchone()
            if not student:
                flash("Student not found.", "danger")
                return redirect(url_for(redirect_to))
            
            cursor.execute("""
                UPDATE users 
                SET section = %s,
                    full_name = CASE WHEN %s != '' THEN %s ELSE full_name END,
                    email = CASE WHEN %s != '' THEN %s ELSE email END
                WHERE id = %s AND role = 'student'
            """, (new_section, new_name, new_name, new_email, new_email, user_id))
            db.commit()
            log_audit_event(
                'STUDENT_UPDATED_BY_ADMIN',
                f"Admin {session.get('full_name')} updated student #{user_id} ('{student['full_name']}') section to '{new_section or 'None'}'.",
                user_id=session.get('user_id'),
                user_name=session.get('full_name'),
                user_role=session.get('role'),
                ip_address=request.remote_addr
            )
            flash(f"Student '{student['full_name']}' updated successfully. Section is now '{new_section or 'None'}'.", "success")
        except Exception as e:
            flash("An error occurred while updating student record.", "danger")
        finally:
            db.close()
    return redirect(url_for(redirect_to))

def _registration_role_label(role):
    """
    PURPOSE: Maps a registered user's role to a human-readable account type label.
    ACCESS:  Internal helper
    """
    return "Proctor (Faculty)" if role == 'proctor' else "Student"

@app.route("/students/approve/<int:id>", methods=["POST"])
def admin_approve_student(id):
    """
    PURPOSE: Approves pending student/proctor registration, activating their account for portal access.
    ACCESS:  Super Admin (registration approvals are handled in User Management)
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard
    user = get_user_by_id(id)
    if not user:
        flash("This registration no longer exists. It may have already been processed.", "reg_error")
        return redirect(url_for('students_page'))
    label = _registration_role_label(user.get('role'))
    approve_student(id)
    log_audit_event('REGISTRATION_APPROVED',
        f"Admin {session.get('full_name')} approved {label.lower()} registration for '{user.get('full_name')}' (ID #{id}).",
        user_id=session.get('user_id'),
        user_name=session.get('full_name'),
        user_role=session.get('role'),
        ip_address=request.remote_addr
    )
    flash(f"{label} account for {user.get('full_name')} has been approved. They have been notified.", "reg_approved")
    return redirect(url_for('students_page'))

@app.route("/students/reject/<int:id>", methods=["POST"])
def admin_reject_student(id):
    """
    PURPOSE: Rejects unverified student self-registration request.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    user = get_user_by_id(id)
    if not user:
        flash("This account no longer exists.", "warning")
        return redirect(url_for('students_page'))
    label = _registration_role_label(user.get('role'))
    err = delete_user(id)
    if err:
        flash(f"Could not delete the {label.lower()} account.", "danger")
    else:
        log_audit_event('STUDENT_DELETED',
            f"Admin {session.get('full_name')} deleted {label.lower()} account '{user.get('full_name')}' (ID #{id}).",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role=session.get('role'),
            ip_address=request.remote_addr
        )
        flash(f"{label} account for {user.get('full_name')} has been deleted.", "success")
    return redirect(url_for('students_page'))

@app.route("/students/deactivate/<int:id>", methods=["POST"])
def admin_deactivate_student(id):
    """
    PURPOSE: Suspends a student account, blocking portal login.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    deactivate_student(id)
    flash("Student account deactivated.", "warning")
    return redirect(url_for('students_page'))

@app.route("/students/reactivate/<int:id>", methods=["POST"])
def admin_reactivate_student(id):
    """
    PURPOSE: Re-activates a suspended student account.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    approve_student(id)   # approve_student sets is_active=1 and notifies
    flash(" Student account reactivated.", "success")
    return redirect(url_for('students_page'))

@app.route("/students/bulk_action", methods=["POST"])
def students_bulk_action():
    """
    PURPOSE: Executes bulk approval, deactivation, or deletion across selected student accounts.
    ACCESS:  Admin, Super Admin
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    action   = request.form.get('bulk_action', '')
    ids_raw  = request.form.getlist('selected_ids')
    try:
        user_ids = [int(i) for i in ids_raw if i.strip().isdigit()]
    except Exception:
        user_ids = []
    if not user_ids:
        flash("No students selected.", "warning")
        return redirect(url_for('students_page'))
    if action == 'deactivate':
        bulk_deactivate_students(user_ids)
        flash(f" {len(user_ids)} student(s) deactivated.", "warning")
    elif action == 'delete':
        bulk_delete_students(user_ids)
        flash(f" {len(user_ids)} student(s) deleted.", "danger")
    elif action == 'approve':
        if not session.get('is_super_admin'):
            flash("Registration approvals are handled by the Super Admin in User Management.", "warning")
            return redirect(url_for('students_page'))
        n_students = n_proctors = 0
        for uid in user_ids:
            u = get_user_by_id(uid)
            if not u:
                continue
            if u.get('role') == 'proctor':
                n_proctors += 1
            else:
                n_students += 1
            approve_student(uid)
        parts = []
        if n_students: parts.append(f"{n_students} student(s)")
        if n_proctors: parts.append(f"{n_proctors} proctor (faculty) account(s)")
        flash(f"{' and '.join(parts) or 'No'} registration(s) approved.", "reg_approved")
    elif action == 'reset_password':
        import bcrypt as _bcrypt
        db = open_db()
        if db:
            try:
                c = db.cursor(dictionary=True)
                format_strings = ','.join(['%s'] * len(user_ids))
                c.execute(f"SELECT id, full_name FROM users WHERE id IN ({format_strings}) AND role='student'", user_ids)
                students = c.fetchall()
                for st in students:
                    pw = derive_user_reset_password(st['full_name'])
                    hashed = _bcrypt.hashpw(pw.encode(), _bcrypt.gensalt()).decode()
                    c.execute("UPDATE users SET password = %s WHERE id = %s", (hashed, st['id']))
                db.commit()
                flash(f"Secure randomized temporary passwords generated for {len(students)} student(s).", "success")
            except Exception as e:
                flash("An error occurred while resetting passwords.", "danger")
            finally:
                db.close()
    else:
        flash("Unknown action.", "danger")
    return redirect(url_for('students_page'))

# ==============================================================================
# SECTION 17: SUPER ADMINISTRATOR CONSOLE
# ==============================================================================

@app.route("/super_admin")
def super_admin_page():
    """
    PURPOSE: Master administrative cockpit overseeing user roles, registration queues, and system audits.
    ACCESS:  Super Admin
    METHOD:  GET
    """
    guard = require_super_admin()
    if guard: return guard
    users            = get_all_users()
    pending_students = get_pending_users()
    institutes       = get_all_institutes()
    unread           = _get_unread(session['user_id'])
    pending_reset_requests = get_all_schedule_reset_requests(pending_only=True)
    sections         = get_all_sections()
    return render_template("super_admin.html",
                           users=users,
                           pending_students=pending_students,
                           institutes=institutes,
                           roles=['admin', 'proctor', 'student', 'secretary'],
                           pending_reset_requests=pending_reset_requests,
                           sections=sections,
                           unread_count=unread)

@app.route("/super_admin/approve_student/<int:id>", methods=["POST"])
def approve_student_route(id):
    """
    PURPOSE: Super Admin route to approve pending student account registration.
    ACCESS:  Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard
    user = get_user_by_id(id)
    if not user:
        flash("This registration no longer exists. It may have already been processed.", "reg_error")
        return redirect(url_for('super_admin_page'))
    label = _registration_role_label(user.get('role'))
    approve_student(id)
    log_audit_event('STUDENT_APPROVED' if user.get('role') != 'proctor' else 'PROCTOR_APPROVED',
        f"Super Admin {session.get('full_name')} approved {label.lower()} account for '{user.get('full_name')}' (ID #{id}).",
        user_id=session.get('user_id'),
        user_name=session.get('full_name'),
        user_role='super_admin',
        ip_address=request.remote_addr
    )
    flash(f"{label} account for {user.get('full_name')} has been approved. They have been notified.", "reg_approved")
    return redirect(url_for('super_admin_page'))

@app.route("/super_admin/reject_student/<int:id>", methods=["POST"])
def reject_student_route(id):
    """
    PURPOSE: Super Admin route to reject pending student registration request.
    ACCESS:  Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard
    user = get_user_by_id(id)
    if not user:
        flash("This registration no longer exists. It may have already been processed.", "reg_error")
        return redirect(url_for('super_admin_page'))
    label = _registration_role_label(user.get('role'))
    err = delete_user(id)
    if err:
        flash(f"Could not reject the {label.lower()} registration.", "reg_error")
    else:
        log_audit_event('STUDENT_REJECTED' if user.get('role') != 'proctor' else 'PROCTOR_REJECTED',
            f"Super Admin {session.get('full_name')} rejected {label.lower()} registration for '{user.get('full_name')}' (ID #{id}).",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role='super_admin',
            ip_address=request.remote_addr
        )
        flash(f"{label} registration for {user.get('full_name')} has been rejected and removed.", "reg_rejected")
    return redirect(url_for('super_admin_page'))

@app.route("/super_admin/edit_user/<int:id>", methods=["POST"])
def super_edit_user(id):
    """
    PURPOSE: Edits any user record including role changes, institute, and section reassignment.
    ACCESS:  Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard
    try:
        # Construct full name from 4 fields if they exist, otherwise fallback to "name"
        last = request.form.get("last_name", "").strip()
        first = request.form.get("first_name", "").strip()
        middle = request.form.get("middle_name", "").strip()
        suffix = request.form.get("suffix", "").strip()
        
        if last and first:
            # Format: Lastname, Firstname M. Suffix
            full_name = f"{last}, {first}"
            if middle:
                full_name += f" {middle[0]}." if len(middle) == 1 else f" {middle}"
            if suffix:
                full_name += f" {suffix}"
        else:
            full_name = request.form.get("name", "").strip()
            
        email        = request.form.get("email", "").strip().lower().replace('ñ', 'n').replace('Ñ', 'n')
        role         = request.form.get("role", "student").strip()
        section      = request.form.get("section", "").strip()
        institute_id = int(request.form.get("institute_id")) if request.form.get("institute_id") and request.form.get("institute_id").strip().isdigit() and int(request.form.get("institute_id")) > 0 else None
        is_sa        = 1 if request.form.get("is_super_admin") else 0

        # Validate role
        if role not in ("admin", "secretary", "proctor", "student"):
            flash("Invalid role selected.", "danger")
            return redirect(url_for('super_admin_page'))

        # GET OLD USER DETAILS FIRST before updating DB!
        from system.database import open_db, update_user
        db = open_db()
        old_user = None
        if db:
            try:
                c = db.cursor(dictionary=True)
                c.execute("SELECT email, role, is_super_admin, full_name FROM users WHERE id = %s", (id,))
                old_user = c.fetchone()
            finally:
                db.close()

        # Security safeguard: Student accounts cannot be promoted to Admin or Super Admin
        if old_user and old_user.get('role') == 'student':
            if role == 'admin' or is_sa:
                flash("Security Policy: Student accounts cannot be promoted to Admin or granted Super Admin privileges.", "danger")
                return redirect(url_for('super_admin_page'))
        if role == 'student':
            is_sa = 0

        # Update local DB
        update_user(id, full_name, email, role, section, institute_id, is_sa)
        
        # Log role promotion or permissions elevation
        if old_user:
            old_role = old_user.get('role')
            old_is_sa = old_user.get('is_super_admin', 0)
            if old_role != role or bool(old_is_sa) != bool(is_sa):
                log_audit_event('USER_ROLE_PROMOTION',
                    f"Super Admin {session.get('full_name')} modified user ID #{id} ({full_name}) privileges: Role: '{old_role}' -> '{role}', SuperAdmin: {bool(old_is_sa)} -> {bool(is_sa)}.",
                    user_id=session.get('user_id'),
                    user_name=session.get('full_name'),
                    user_role='super_admin',
                    ip_address=request.remote_addr
                )
        flash(f"User '{full_name}' updated successfully to role '{role}'.", "success")
    except Exception as e:
        flash(f"Error updating user: {str(e)}", "danger")
    return redirect(url_for('super_admin_page'))


@app.route("/super_admin/update_email", methods=["POST"])
def super_update_email():
    """
    PURPOSE: Updates the registered email address for a user account.
    ACCESS:  Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard
    
    new_email = request.form.get("new_email", "").strip().lower().replace('ñ', 'n').replace('Ñ', 'n')
    if not new_email.endswith("@cca.edu.ph"):
        flash("Email must be a valid @cca.edu.ph address.", "danger")
        return redirect(url_for('super_admin_page'))
        
    user_id = session.get('user_id')
    db = open_db()
    if db:
        try:
            c = db.cursor(dictionary=True)
            # Check if email is already used by someone else
            c.execute("SELECT id FROM users WHERE email = %s AND id != %s", (new_email, user_id))
            if c.fetchone():
                flash("That email is already in use.", "danger")
                return redirect(url_for('super_admin_page'))
                
            # Get current email to verify user exists
            c.execute("SELECT email FROM users WHERE id = %s", (user_id,))
            current_user = c.fetchone()
            
            if current_user:
                c.execute("UPDATE users SET email = %s WHERE id = %s", (new_email, user_id))
                db.commit()
                flash("Superadmin email has been successfully updated! Password resets will now go to this new address.", "success")
        except Exception as e:
            flash("An error occurred while updating email.", "danger")
        finally:
            db.close()
    return redirect(url_for('super_admin_page'))

@app.route("/super_admin/delete_user/<int:id>", methods=["POST"])
def super_delete_user(id):
    """
    PURPOSE: Permanently removes a user account from the system.
    ACCESS:  Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard
    if id == session.get('user_id'):
        flash("Cannot delete your own account.", "danger")
        return redirect(url_for('super_admin_page'))
    
    # Retrieve user info for audit trace
    target_info = f"User #{id}"
    db = open_db()
    if db:
        try:
            c = db.cursor(dictionary=True)
            c.execute("SELECT full_name, email, role FROM users WHERE id = %s", (id,))
            row = c.fetchone()
            if row:
                target_info = f"{row.get('full_name')} ({row.get('email')}, role: {row.get('role')})"
        finally:
            db.close()

    err = delete_user(id)
    if err:
        flash(f"Cannot delete: {err}", "danger")
    else:
        log_audit_event('USER_DELETED',
            f"Super Admin {session.get('full_name')} permanently deleted user account: {target_info}.",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role='super_admin',
            ip_address=request.remote_addr
        )
        flash("User deleted.", "success")
    return redirect(url_for('super_admin_page'))

@app.route("/super_admin/bulk_delete_users", methods=["POST"])
def super_bulk_delete_users():
    """
    PURPOSE: Bulk deletes multiple selected user accounts.
    ACCESS:  Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard

    delete_all_role = (request.form.get("delete_all_role") or "").strip().lower()
    raw_ids = request.form.getlist("user_ids")
    csv_ids = request.form.get("user_ids_csv", "").strip()
    if csv_ids:
        raw_ids.extend([x.strip() for x in csv_ids.split(",") if x.strip()])

    if not delete_all_role and not raw_ids:
        flash("No users selected for deletion.", "warning")
        return redirect(url_for('super_admin_page'))

    deleted_count, errors = bulk_delete_users_and_proctors(
        user_ids=raw_ids if not delete_all_role else None,
        delete_all_role=delete_all_role if delete_all_role in ('proctor', 'student', 'secretary') else None,
        exclude_user_id=session.get('user_id')
    )

    if deleted_count > 0:
        action_target = f"all {delete_all_role} accounts ({deleted_count})" if delete_all_role else f"{deleted_count} selected user account(s)"
        log_audit_event('USER_BULK_DELETED',
            f"Super Admin {session.get('full_name')} permanently bulk-deleted {action_target}.",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role='super_admin',
            ip_address=request.remote_addr
        )
        if delete_all_role == 'proctor':
            flash(f"Successfully deleted all {deleted_count} proctor account(s) and cleared faculty proctor records.", "success")
        else:
            flash(f"Successfully deleted {deleted_count} user account(s).", "success")
    elif not errors:
        flash("No matching user accounts were found to delete.", "info")

    if errors:
        flash("Some accounts could not be deleted: " + "; ".join(errors[:5]), "warning")

    return redirect(url_for('super_admin_page'))

@app.route("/super_admin/reset_password/<int:id>", methods=["POST"])
def super_reset_password(id):
    """
    PURPOSE: Super Admin override to reset credentials for any user account.
    ACCESS:  Super Admin
    METHOD:  POST
    """
    guard = require_super_admin()
    if guard: return guard
    db = open_db()
    if db:
        try:
            import bcrypt as _bcrypt
            c = db.cursor(dictionary=True)
            c.execute("SELECT id, full_name, email, role FROM users WHERE id = %s", (id,))
            target_user = c.fetchone()
            if not target_user:
                flash("User not found.", "danger")
                return redirect(url_for('super_admin_page'))
            
            custom_pw = request.form.get("new_password", "").strip()
            if custom_pw:
                default_pw = custom_pw
            else:
                default_pw = derive_user_reset_password(target_user.get('full_name') or 'User')
            
            hashed = _bcrypt.hashpw(default_pw.encode(), _bcrypt.gensalt()).decode()
            c.execute("UPDATE users SET password = %s WHERE id = %s", (hashed, id))
            db.commit()
            flash(f"Password for {target_user['full_name']} reset to default ({default_pw}) successfully.", "success")
        except Exception as e:
            flash(f"Error resetting password: {e}", "danger")
        finally:
            db.close()
    return redirect(url_for('super_admin_page'))

# ==============================================================================
# SECTION 18: PROCTOR PORTAL & AVAILABILITY SUBMISSION
# ==============================================================================

@app.route("/proctor")
@app.route("/proctor/dashboard")
def proctor_dashboard():
    """
    PURPOSE: Faculty proctor portal displaying assigned exam shifts, room locations, and guidelines.
    ACCESS:  Proctor, Faculty
    METHOD:  GET
    """
    guard = require_role('proctor')
    if guard: return guard
    is_pub = is_schedule_published()
    instructor_id = session.get('instructor_id')
    if not is_pub:
        exams = []
        total_hours = 0.0
        sorted_groups = []
    else:
        exams = get_proctor_exams(instructor_id) if instructor_id else []
        total_hours = get_proctor_total_hours(instructor_id) if instructor_id else 0.0
        grouped = defaultdict(list)
        for exam in exams:
            dt = exam['exam_date_time']
            if not dt: continue
            if isinstance(dt, str):
                dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
            dur = int(exam.get('duration_minutes') or 60)
            end_dt = dt + timedelta(minutes=dur)
            exam['time'] = dt.strftime("%I:%M %p")
            exam['time_end'] = end_dt.strftime("%I:%M %p")
            exam['time_range'] = f"{exam['time']} - {exam['time_end']}"
            grouped[dt.strftime("%A, %B %d, %Y")].append(exam)
        sorted_groups = sorted(grouped.items(),
                               key=lambda x: datetime.strptime(x[0], "%A, %B %d, %Y"))
    saved_dates = get_proctor_availability_for(instructor_id) if instructor_id else []
    period_start, period_end = get_exam_period()
    period_dates = []
    if period_start and period_end:
        cur = period_start
        while cur <= period_end:
            period_dates.append(str(cur))
            cur += timedelta(days=1)
    unread = _get_unread(session['user_id'])
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    full_name = session.get('full_name', 'Faculty Proctor')
    prepared_by = session.get('full_name', 'Faculty Proctor')

    proctor_institute_name = ''
    proctor_institute_code = ''
    db = open_db()
    if db:
        try:
            c = db.cursor(dictionary=True)
            c.execute("""
                SELECT inst.name AS institute_name, inst.code AS institute_code
                FROM users u
                LEFT JOIN instructors i ON u.instructor_id = i.id
                LEFT JOIN institutes inst ON COALESCE(i.institute_id, u.institute_id) = inst.id
                WHERE u.id = %s
            """, (session['user_id'],))
            inst_row = c.fetchone()
            if inst_row:
                proctor_institute_name = inst_row.get('institute_name') or ''
                proctor_institute_code = inst_row.get('institute_code') or ''
                session['institute_name'] = proctor_institute_name
                session['institute_code'] = proctor_institute_code
        finally:
            db.close()

    return render_template("proctor_dashboard.html",
                           grouped=sorted_groups,
                           exams=exams,
                           total=len(exams),
                           full_name=full_name,
                           proctor_institute_name=proctor_institute_name,
                           proctor_institute_code=proctor_institute_code,
                           exam_term=exam_term,
                           exam_semester=exam_semester,
                           saved_dates=saved_dates,
                           period_dates=period_dates,
                           period_start=str(period_start) if period_start else '',
                           period_end=str(period_end) if period_end else '',
                           total_hours=total_hours,
                           unread_count=unread,
                           prepared_by=prepared_by,
                           is_published=is_pub)

@app.route("/proctor/availability")
def proctor_availability():
    """
    PURPOSE: Allows faculty proctors to declare and submit their preferred availability time windows.
    ACCESS:  Proctor, Faculty
    METHOD:  GET, POST
    """
    guard = require_role('proctor')
    if guard: return guard
    
    instructor_id = session.get('instructor_id')
    saved_dates = get_proctor_availability_for(instructor_id) if instructor_id else []
    period_start, period_end = get_exam_period()
    is_pub = is_schedule_published()
    exams = get_proctor_exams(instructor_id) if (instructor_id and is_pub) else []
    total_hours = get_proctor_total_hours(instructor_id) if (instructor_id and is_pub) else 0.0
    
    for exam in exams:
        dt = exam.get('exam_date_time')
        if not dt: continue
        if isinstance(dt, str):
            try:
                dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
            except Exception:
                pass
        if isinstance(dt, datetime):
            dur = int(exam.get('duration_minutes') or 60)
            end_dt = dt + timedelta(minutes=dur)
            exam['date_iso'] = dt.strftime("%Y-%m-%d")
            exam['time'] = dt.strftime("%I:%M %p")
            exam['time_end'] = end_dt.strftime("%I:%M %p")
            exam['time_range'] = f"{exam['time']} - {exam['time_end']}"

    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    
    full_name = session.get('full_name', 'Faculty Proctor')
    
    proctor_institute_name = session.get('institute_name', '')
    proctor_institute_code = session.get('institute_code', '')
    if not proctor_institute_name or not proctor_institute_code:
        db = open_db()
        if db:
            try:
                c = db.cursor(dictionary=True)
                c.execute("""
                    SELECT inst.name AS institute_name, inst.code AS institute_code
                    FROM users u
                    LEFT JOIN instructors i ON u.instructor_id = i.id
                    LEFT JOIN institutes inst ON COALESCE(i.institute_id, u.institute_id) = inst.id
                    WHERE u.id = %s
                """, (session['user_id'],))
                inst_row = c.fetchone()
                if inst_row:
                    proctor_institute_name = inst_row.get('institute_name') or ''
                    proctor_institute_code = inst_row.get('institute_code') or ''
                    session['institute_name'] = proctor_institute_name
                    session['institute_code'] = proctor_institute_code
            finally:
                db.close()
                
    unread = _get_unread(session['user_id'])
    
    formatted_saved_dates = []
    for slot in saved_dates:
        s_raw = slot.get('start_time', '07:00')
        e_raw = slot.get('end_time', '20:00')
        def _fmt_time(t_str):
            try:
                parts = str(t_str).split(':')
                h = int(parts[0])
                m = int(parts[1]) if len(parts) > 1 else 0
                dt_tmp = datetime(2000, 1, 1, h, m)
                return dt_tmp.strftime("%I:%M %p")
            except Exception:
                return str(t_str)
        formatted_saved_dates.append({
            'date': slot.get('date'),
            'start_time': slot.get('start_time'),
            'end_time': slot.get('end_time'),
            'start_time_fmt': _fmt_time(s_raw),
            'end_time_fmt': _fmt_time(e_raw),
            'time_range_fmt': f"{_fmt_time(s_raw)} - {_fmt_time(e_raw)}"
        })
    
    return render_template(
        "proctor_availability.html",
        full_name=full_name,
        proctor_institute_name=proctor_institute_name,
        proctor_institute_code=proctor_institute_code,
        exam_term=exam_term,
        exam_semester=exam_semester,
        saved_dates=formatted_saved_dates,
        period_start=str(period_start) if period_start else '',
        period_end=str(period_end) if period_end else '',
        exams=exams,
        total_hours=total_hours,
        unread_count=unread,
        is_published=is_pub
    )

@app.route("/proctor/schedule.pdf")
def export_proctor_schedule_pdf_route():
    """
    PURPOSE: Exports personalized proctoring shift schedule into printable PDF slip.
    ACCESS:  Proctor, Faculty
    METHOD:  GET
    """
    guard = require_role('proctor')
    if guard: return guard
    if not is_schedule_published():
        flash("The official examination timetable is currently in Draft mode under administrative review. Proctor duty slips cannot be downloaded yet.", "warning")
        return redirect(url_for('proctor_dashboard'))
    instructor_id = session.get('instructor_id')
    if not instructor_id:
        flash("Instructor profile not linked to account.", "danger")
        return redirect(url_for('proctor_dashboard'))
    
    exams = get_proctor_exams(instructor_id)
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    total_hours = get_proctor_total_hours(instructor_id)
    
    from system.exporter import export_proctor_duty_slip_pdf
    pdf_bytes = export_proctor_duty_slip_pdf(
        proctor_name=session.get('full_name', 'Faculty Proctor'),
        exams=exams,
        exam_term=exam_term,
        exam_semester=exam_semester,
        total_hours=total_hours,
        prepared_by=session.get('full_name', 'Faculty Proctor')
    )
    
    import re
    safe_name = re.sub(r'[^a-zA-Z0-9]+', '_', session.get('full_name', 'proctor')).strip('_').lower()
    filename = f"proctor_schedule_{safe_name}.pdf" if safe_name else "proctor_schedule.pdf"
    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype='application/pdf',
        as_attachment=False,
        download_name=filename
    )



@app.route("/proctor/report_absence", methods=["POST"])
def proctor_report_absence():
    """
    PURPOSE: Allows proctor to log emergency absence for an assigned shift, notifying department secretary.
    ACCESS:  Proctor, Faculty
    METHOD:  POST
    """
    guard = require_role('proctor')
    if guard: return guard
    instructor_id = session.get('instructor_id')
    exam_id       = request.form.get("exam_id")
    reason        = request.form.get("reason", "").strip()
    if not exam_id:
        flash("Select an exam.", "warning")
        return redirect(url_for('proctor_dashboard'))
    
    # Prevent duplicate absence submissions for the same exam
    db = open_db()
    if db:
        try:
            c = db.cursor(dictionary=True)
            c.execute("""
                SELECT pa.id, (SELECT COUNT(*) FROM relievers rel WHERE rel.exam_id = %s) as has_reliever
                FROM proctor_absence pa
                WHERE pa.instructor_id = %s AND pa.exam_id = %s
                ORDER BY pa.id DESC LIMIT 1
            """, (exam_id, instructor_id, exam_id))
            prev = c.fetchone()
            if prev:
                if prev.get('has_reliever'):
                    flash("A substitute reliever has already been assigned for this exam.", "info")
                    return redirect(url_for('proctor_dashboard'))
                else:
                    flash("An absence report is already pending administrative / secretary review for this exam.", "warning")
                    return redirect(url_for('proctor_dashboard'))
        finally:
            db.close()

    record_proctor_absence(instructor_id, int(exam_id), reason, session['user_id'])
    flash("Absence reported successfully. Your Institute Secretary has been notified.", "info")
    exam = get_exam_by_id(int(exam_id)) if exam_id else {}
    exam_label = f"{exam.get('subject_name', '')} ({exam.get('section', '')})" if exam else f"exam #{exam_id}"
    # Notify admin and secretary roles
    title = f"Proctor Absence: {session.get('full_name', 'Proctor')}"
    msg   = f"{session.get('full_name', 'Proctor')} reported an absence for {exam_label}. Reason: {reason or 'Not specified'}."
    create_notification_for_role('admin', title, msg)
    create_notification_for_role('secretary', title, msg)
    return redirect(url_for('proctor_dashboard'))

# ==============================================================================
# SECTION 19: STANDBY RELIEVER (INVIGILATOR) MANAGEMENT
# ==============================================================================

@app.route("/relievers")
def relievers_page():
    """
    PURPOSE: Reliever management console for tracking standby invigilators available on call.
    ACCESS:  Admin, Super Admin, Secretary
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    relievers  = get_all_relievers()
    exams      = get_all_exams()
    instructors = get_active_instructors()
    unread     = _get_unread(session['user_id'])
    return render_template("faculty.html",  # reuse faculty template with extra context
                           relievers=relievers, exams=exams,
                           instructors=instructors,
                           institutes=get_all_institutes(),
                           subjects=get_all_subjects(),
                           period_summary=get_all_proctor_hours_summary(),
                           buildings=get_all_buildings(),
                           unread_count=unread)

@app.route("/relievers/add", methods=["POST"])
def add_reliever_route():
    """
    PURPOSE: Designates a faculty member as standby reliever for an exam timeslot.
    ACCESS:  Admin, Super Admin, Secretary
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    exam_id       = request.form.get("exam_id")
    instructor_id = request.form.get("instructor_id")
    reason        = request.form.get("reason", "")
    if exam_id and instructor_id:
        add_reliever(int(exam_id), int(instructor_id), reason)
        flash("Reliever assigned.", "success")
        # Notify the reliever
        db = open_db()
        if db:
            try:
                c = db.cursor(dictionary=True)
                c.execute("SELECT u.email, u.full_name FROM users u WHERE u.instructor_id = %s",
                          (instructor_id,))
                row = c.fetchone()
                if row:
                    send_email_notification(row['email'],
                        "CCA â€” You have been assigned as a Reliever",
                        f"Dear {row['full_name']},\n\nYou have been assigned as a reliever proctor for exam #{exam_id}.\n"
                        f"Reason: {reason or 'Not specified'}\n\nPlease log in for details.\n\nCCA Exam Management System")
            finally:
                db.close()
    else:
        flash("Select both exam and instructor.", "warning")
    return redirect(url_for('faculty_page'))

@app.route("/relievers/remove/<int:id>", methods=["POST"])
def remove_reliever_route(id):
    """
    PURPOSE: Removes a standby reliever designation.
    ACCESS:  Admin, Super Admin, Secretary
    METHOD:  POST
    """
    guard = require_role('admin')
    if guard: return guard
    remove_reliever(id)
    flash("Reliever removed.", "success")
    return redirect(url_for('faculty_page'))

# ==============================================================================
# SECTION 20: DEPARTMENT SECRETARY & EXAM LOGISTICS CONTROL
# ==============================================================================

@app.route("/secretary")
@app.route("/secretary/dashboard")
def secretary_dashboard():
    """
    PURPOSE: Department Secretary operational console for managing exam paper release, collection, and relievers.
    ACCESS:  Secretary, Admin
    METHOD:  GET
    """
    guard = require_role('secretary', 'admin')
    if guard: return guard
    is_pub = is_schedule_published()
    # Admins see all institutes; secretaries see only their own
    inst_id     = None if session.get('role') == 'admin' else session.get('institute_id')
    instructors = get_active_instructors()
    unread      = _get_unread(session['user_id'])
    
    if not is_pub and session.get('role') != 'admin':
        exams = []
        stats = {'total': 0, 'collected': 0, 'returned': 0, 'pending_collection': 0}
        pending_absences = []
    else:
        exams       = get_exam_collection_status(institute_id=inst_id)
        for ex in exams:
            dt = ex.get('exam_date_time')
            if dt:
                if isinstance(dt, str):
                    try:
                        dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
                    except Exception:
                        pass
                dur = int(ex.get('duration_minutes') or 60)
                if isinstance(dt, datetime):
                    end_dt = dt + timedelta(minutes=dur)
                    ex['time'] = dt.strftime("%I:%M %p")
                    ex['time_end'] = end_dt.strftime("%I:%M %p")
                    ex['time_range'] = f"{ex['time']} - {ex['time_end']}"
        stats       = get_collection_stats(institute_id=inst_id)
        from system.database import get_unresolved_absences
        pending_absences = get_unresolved_absences(institute_id=inst_id)
    
    return render_template("secretary.html",
                           exams=exams, instructors=instructors,
                           stats=stats, unread_count=unread,
                           institute_id=inst_id,
                           pending_absences=pending_absences,
                           is_published=is_pub)

def _can_secretary_access_exam(exam_id):
    """
    PURPOSE: Enforces departmental boundaries ensuring secretaries only manage exams belonging to their institute.
    ACCESS:  Internal security helper
    """
    if session.get('role') == 'admin':
        return True
    sec_inst_id = session.get('institute_id')
    if not sec_inst_id:
        return False
    from system.database import get_exam_by_id, get_instructor_by_id
    exam = get_exam_by_id(exam_id)
    if not exam:
        return False
    
    # 1. Direct match on exam's institute
    if exam.get('institute_id') and int(exam['institute_id']) == int(sec_inst_id):
        return True

    # 2. Match on assigned instructor's home institute (for cross-department proctors)
    if exam.get('instructor_id'):
        instructor = get_instructor_by_id(exam['instructor_id'])
        if instructor and instructor.get('institute_id') and int(instructor['institute_id']) == int(sec_inst_id):
            return True

    # 3. Match on proctor absence records for this exam
    from system.database import open_db
    db = open_db()
    if db:
        try:
            c = db.cursor(dictionary=True)
            c.execute("""
                SELECT p.id FROM proctor_absence p
                JOIN instructors i ON p.instructor_id = i.id
                WHERE p.exam_id = %s AND i.institute_id = %s
                LIMIT 1
            """, (exam_id, sec_inst_id))
            if c.fetchone():
                return True
        finally:
            db.close()

    # If exam has no institute assigned at all, allow access
    if not exam.get('institute_id'):
        return True

    return False

@app.route("/api/substitute_candidates/<int:exam_id>", methods=["GET"])
def api_substitute_candidates(exam_id):
    """
    PURPOSE: Suggests eligible substitute proctors free during a specific exam slot to replace an absent invigilator.
    ACCESS:  Secretary, Admin
    METHOD:  GET
    """
    guard = require_role('secretary', 'admin')
    if guard: return jsonify({'error': 'Not authorised'}), 403
    if not _can_secretary_access_exam(exam_id):
        return jsonify({'error': 'Access denied. Exam is outside your assigned department.'}), 403
    inst_id = None if session.get('role') == 'admin' else session.get('institute_id')
    from system.database import get_substitute_candidates
    data = get_substitute_candidates(exam_id, institute_id=inst_id)
    if not data: return jsonify({'error': 'Exam not found'}), 404
    return jsonify(data)

@app.route("/secretary/assign_substitute", methods=["POST"])
def secretary_assign_substitute():
    """
    PURPOSE: Reassigns an exam slot from an absent proctor to an available substitute invigilator.
    ACCESS:  Secretary, Admin
    METHOD:  POST
    """
    guard = require_role('secretary', 'admin')
    if guard: return guard
    exam_id = request.form.get("exam_id")
    new_inst_id = request.form.get("instructor_id")
    new_room_id = request.form.get("room_id")
    reason = request.form.get("reason", "").strip()

    if not exam_id or not new_inst_id:
        flash("Please select an exam and substitute proctor.", "warning")
        return redirect(url_for('secretary_dashboard'))

    try:
        eid = int(exam_id)
    except (ValueError, TypeError):
        flash("Invalid exam identifier.", "danger")
        return redirect(url_for('secretary_dashboard'))

    if not _can_secretary_access_exam(eid):
        flash("Access denied. You can only assign substitute proctors for exams within your assigned department.", "danger")
        return redirect(url_for('secretary_dashboard'))

    from system.database import reassign_exam_proctor_room
    ok, msg = reassign_exam_proctor_room(eid, int(new_inst_id), new_room_id=new_room_id, reason=reason, reassigned_by=session.get('user_id'))
    if ok:
        log_audit_event('PROCTOR_SUBSTITUTE_ASSIGNED',
            f"Secretary {session.get('full_name')} assigned substitute instructor #{new_inst_id} to exam #{eid}. Reason: '{reason}'.",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role=session.get('role'),
            ip_address=request.remote_addr
        )
        # Notify the substitute proctor immediately via email
        try:
            db_sub = open_db()
            if db_sub:
                c_sub = db_sub.cursor(dictionary=True)
                c_sub.execute("""
                    SELECT e.subject_name, e.section, e.exam_date_time, r.room_name
                    FROM exams e
                    LEFT JOIN rooms r ON e.room_id = r.id
                    WHERE e.id = %s
                """, (eid,))
                ex_info = c_sub.fetchone()
                c_sub.execute("SELECT email, full_name FROM users WHERE instructor_id = %s", (new_inst_id,))
                sub_user = c_sub.fetchone()
                if ex_info and sub_user and sub_user.get('email'):
                    dt = ex_info.get('exam_date_time')
                    dt_str = dt.strftime('%B %d, %Y at %I:%M %p') if dt else 'TBD'
                    rm_str = ex_info.get('room_name') or 'TBD'
                    sec_name = session.get('full_name', 'Department Secretary')
                    sub_body = (
                        f"Dear Prof. {sub_user['full_name']},\n\n"
                        f"You have been assigned as a substitute proctor for the following examination:\n\n"
                        f"Subject: {ex_info.get('subject_name')} ({ex_info.get('section') or '-' })\n"
                        f"Date & Time: {dt_str}\n"
                        f"Room: {rm_str}\n"
                        f"Reason: {reason or 'Emergency substitute proctor duty'}\n"
                        f"Assigned By: {sec_name}\n\n"
                        f"Please log in to your Proctor Dashboard to review details and download your duty pass:\n"
                        f"https://cca-exam.duckdns.org/proctor/dashboard\n\n"
                        f"Best regards,\nCCA Exam Management System"
                    )
                    send_email_notification(
                        sub_user['email'],
                        f"CCA Exam Proctoring Assignment (Substitute Reliever) - {ex_info.get('subject_name')}",
                        sub_body
                    )
                db_sub.close()
        except Exception as sub_mail_err:
            print(f"[Secretary Substitute Mail Error] {sub_mail_err}")
        flash(msg, "success")
    else:
        flash(f"Failed to assign substitute: {msg}", "danger")
    return redirect(url_for('secretary_dashboard'))


@app.route("/secretary/collect/<int:exam_id>", methods=["POST"])
def secretary_collect(exam_id):
    """
    PURPOSE: Records proctor check-in and pickup of examination questionnaire packets.
    ACCESS:  Secretary, Admin
    METHOD:  POST
    """
    guard = require_role('secretary', 'admin')
    if guard: return guard
    if not _can_secretary_access_exam(exam_id):
        flash("Access denied. You can only collect exams within your assigned department.", "danger")
        return redirect(url_for('secretary_dashboard'))
    instructor_id = request.form.get("collected_by_instructor_id") or None
    notes         = request.form.get("notes", "")
    mark_exam_collected(exam_id, instructor_id, notes)
    log_audit_event('EXAM_COLLECTED',
        f"Secretary {session.get('full_name')} marked exam #{exam_id} as collected.",
        user_id=session.get('user_id'),
        user_name=session.get('full_name'),
        user_role=session.get('role'),
        ip_address=request.remote_addr
    )
    flash("Marked as collected.", "success")
    return redirect(url_for('secretary_dashboard'))

@app.route("/secretary/batch_collect", methods=["POST"])
def secretary_batch_collect():
    """
    PURPOSE: Bulk records material collection across multiple ongoing exams.
    ACCESS:  Secretary, Admin
    METHOD:  POST
    """
    guard = require_role('secretary', 'admin')
    if guard: return guard
    raw_exam_ids = request.form.getlist("exam_ids")
    if not raw_exam_ids:
        comma_ids = request.form.get("exam_ids", "")
        if comma_ids:
            raw_exam_ids = [x.strip() for x in comma_ids.split(",") if x.strip()]
    
    instructor_id = request.form.get("collected_by_instructor_id") or None
    notes         = request.form.get("notes", "")

    collected_count = 0
    skipped_count = 0
    for eid_str in raw_exam_ids:
        try:
            eid = int(eid_str)
            if not _can_secretary_access_exam(eid):
                skipped_count += 1
                continue
            mark_exam_collected(eid, instructor_id, notes)
            collected_count += 1
        except (ValueError, TypeError):
            continue

    if collected_count > 0:
        log_audit_event('EXAM_BATCH_COLLECTED',
            f"Secretary {session.get('full_name')} marked {collected_count} exam envelope(s) as collected.",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role=session.get('role'),
            ip_address=request.remote_addr
        )
        msg = f"Successfully marked {collected_count} exam envelope(s) as collected."
        if skipped_count > 0:
            msg += f" ({skipped_count} exam(s) outside your assigned department were skipped)."
        flash(msg, "success")
    else:
        if skipped_count > 0:
            flash(f"Access denied: {skipped_count} selected exam(s) belong to other departments.", "danger")
        else:
            flash("No valid exams were selected for collection.", "warning")
    return redirect(url_for('secretary_dashboard'))

@app.route("/secretary/return/<int:exam_id>", methods=["POST"])
def secretary_return(exam_id):
    """
    PURPOSE: Records safe return of completed student answer sheets and test materials post-exam.
    ACCESS:  Secretary, Admin
    METHOD:  POST
    """
    guard = require_role('secretary', 'admin')
    if guard: return guard
    if not _can_secretary_access_exam(exam_id):
        flash("Access denied. You can only return exams within your assigned department.", "danger")
        return redirect(url_for('secretary_dashboard'))
    notes = request.form.get("notes", "")
    mark_exam_returned(exam_id, notes)
    log_audit_event('EXAM_RETURNED',
        f"Secretary {session.get('full_name')} marked exam #{exam_id} as returned.",
        user_id=session.get('user_id'),
        user_name=session.get('full_name'),
        user_role=session.get('role'),
        ip_address=request.remote_addr
    )
    flash("Marked as returned.", "success")
    return redirect(url_for('secretary_dashboard'))

@app.route("/secretary/batch_return", methods=["POST"])
def secretary_batch_return():
    """
    PURPOSE: Bulk marks exam materials as returned to academic department custody.
    ACCESS:  Secretary, Admin
    METHOD:  POST
    """
    guard = require_role('secretary', 'admin')
    if guard: return guard
    raw_exam_ids = request.form.getlist("exam_ids")
    if not raw_exam_ids:
        comma_ids = request.form.get("exam_ids", "")
        if comma_ids:
            raw_exam_ids = [x.strip() for x in comma_ids.split(",") if x.strip()]
    
    notes = request.form.get("notes", "").strip()

    returned_count = 0
    skipped_count = 0
    for eid_str in raw_exam_ids:
        try:
            eid = int(eid_str)
            if not _can_secretary_access_exam(eid):
                skipped_count += 1
                continue
            mark_exam_returned(eid, notes)
            returned_count += 1
        except Exception as e:
            print(f"Error returning exam {eid_str}: {e}")
            continue

    if returned_count > 0:
        log_audit_event('EXAM_BATCH_RETURNED',
            f"Secretary {session.get('full_name')} marked {returned_count} exam envelope(s) as returned.",
            user_id=session.get('user_id'),
            user_name=session.get('full_name'),
            user_role=session.get('role'),
            ip_address=request.remote_addr
        )
        msg = f"Successfully marked {returned_count} exam envelope(s) as returned."
        if skipped_count > 0:
            msg += f" ({skipped_count} exam(s) outside your assigned department were skipped)."
        flash(msg, "success")
    else:
        if skipped_count > 0:
            flash(f"Access denied: {skipped_count} selected exam(s) belong to other departments.", "danger")
        else:
            flash("No valid exams were selected for return.", "warning")
    return redirect(url_for('secretary_dashboard'))

@app.route("/api/secretary/pending_absences")
@limiter.exempt
def api_secretary_pending_absences():
    """
    PURPOSE: Real-time JSON endpoint for unresolved proctor absences needing immediate relief.
    ACCESS:  Secretary, Admin
    METHOD:  GET
    """
    uid = session.get('user_id')
    role = session.get('role')
    if not uid or role not in ('secretary', 'admin'):
        return jsonify({'error': 'Unauthorized', 'expired': True}), 401

    inst_id = None if role == 'admin' else session.get('institute_id')
    from system.database import get_unresolved_absences
    raw_absences = get_unresolved_absences(institute_id=inst_id)

    formatted = []
    for ab in raw_absences:
        dt = ab.get('exam_date_time')
        dur = ab.get('duration_minutes', 60)
        rep_at = ab.get('reported_at')
        if rep_at and isinstance(rep_at, datetime):
            rep_str = rep_at.strftime('%b %d, %I:%M %p')
        else:
            rep_str = str(rep_at or '')

        formatted.append({
            'id': ab['id'],
            'exam_id': ab['exam_id'],
            'instructor_id': ab.get('instructor_id'),
            'instructor_name': ab.get('instructor_name') or 'Unassigned',
            'subject_name': ab.get('subject_name') or '',
            'section': ab.get('section') or '',
            'room_name': ab.get('room_name') or 'TBD',
            'reason': ab.get('reason') or '',
            'schedule_fmt': exam_datetime_range_filter(dt, dur) if dt else 'TBD',
            'reported_at': rep_str
        })

    resp = jsonify({'success': True, 'count': len(formatted), 'absences': formatted})
    resp.headers['Cache-Control'] = 'no-store'
    return resp

@app.route("/secretary/change_password", methods=["POST"])
def secretary_change_password():
    """
    PURPOSE: Allows Department Secretary to update account password.
    ACCESS:  Secretary
    METHOD:  POST
    """
    guard = require_role('secretary', 'admin')
    if guard: return guard

    current_password = request.form.get("current_password", "").strip()
    new_password     = request.form.get("new_password", "").strip()
    confirm_password = request.form.get("confirm_password", "").strip()

    # Validation
    if not current_password or not new_password or not confirm_password:
        flash("All password fields are required.", "danger")
        return redirect(url_for('secretary_dashboard'))
    is_valid, err_msg = validate_password_strength(new_password)
    if not is_valid:
        flash(err_msg, "danger")
        return redirect(url_for('secretary_dashboard'))
    if new_password != confirm_password:
        flash("New passwords do not match.", "danger")
        return redirect(url_for('secretary_dashboard'))

    db = open_db()
    if db:
        try:
            import bcrypt as _bcrypt
            c = db.cursor(dictionary=True)
            c.execute("SELECT id, full_name, password FROM users WHERE id = %s", (session['user_id'],))
            user = c.fetchone()
            if not user:
                flash("User not found.", "danger")
                return redirect(url_for('secretary_dashboard'))

            # Verify current password strictly using Bcrypt (no plaintext fallback)
            try:
                current_ok = _bcrypt.checkpw(current_password.encode(), user['password'].encode())
            except (ValueError, TypeError, Exception):
                current_ok = False

            if not current_ok:
                flash("Current password is incorrect.", "danger")
                return redirect(url_for('secretary_dashboard'))

            # Save new hashed password
            new_hashed = _bcrypt.hashpw(new_password.encode(), _bcrypt.gensalt()).decode()
            c.execute("UPDATE users SET password = %s WHERE id = %s", (new_hashed, session['user_id']))
            db.commit()
            flash(" Password changed successfully.", "success")
        except Exception as e:
            flash(f"Error: {e}", "danger")
        finally:
            db.close()
    return redirect(url_for('secretary_dashboard'))

# ==============================================================================
# SECTION 21: PROCTOR ABSENCE MONITORING & INCIDENT MANAGEMENT
# ==============================================================================

@app.route("/admin/report_absence", methods=["POST"])
def admin_report_absence():
    """
    PURPOSE: Administrative interface for logging or reallocating proctor absences.
    ACCESS:  Admin, Super Admin
    METHOD:  GET, POST
    """
    guard = require_role('admin')
    if guard: return guard
    instructor_id = request.form.get("instructor_id")
    exam_id       = request.form.get("exam_id")
    reason        = request.form.get("reason", "")
    if instructor_id and exam_id:
        record_proctor_absence(int(instructor_id), int(exam_id), reason, session['user_id'])
        flash("Absence recorded.", "info")
        
        ins = get_instructor_by_id(int(instructor_id)) if instructor_id else {}
        ins_name = ins.get('name', 'Instructor') if ins else 'Instructor'
        exam = get_exam_by_id(int(exam_id)) if exam_id else {}
        exam_label = f"{exam.get('subject_name', '')} ({exam.get('section', '')})" if exam else f"exam #{exam_id}"
        
        title = f"Proctor Absence: {ins_name}"
        msg = f"{ins_name} was reported absent for {exam_label}. Reason: {reason or 'Not specified'}."
        create_notification_for_role('admin', title, msg)
        create_notification_for_role('secretary', title, msg)
    else:
        flash("Select instructor and exam.", "warning")
    return redirect(url_for('reports_page'))

# ==============================================================================
# SECTION 22: REAL-TIME NOTIFICATIONS & LIVE POLLING
# ==============================================================================

@app.route("/notifications/clear_all", methods=["POST"])
def clear_all_notifications_route():
    """
    PURPOSE: Dismisses all notifications for the active user.
    ACCESS:  Authenticated users
    METHOD:  POST
    """
    guard = require_login()
    if guard: return guard
    clear_all_notifications(session['user_id'])
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'ok': True, 'unread_count': 0})
    flash("All notifications cleared.", "success")
    if session.get('role') == 'student':
        return redirect(url_for('student_timetable', open_notifications='1'))
    return redirect(url_for('notifications_page'))

@app.route("/notifications/delete_selected", methods=["POST"])
def delete_selected_notifications_route():
    """
    PURPOSE: Deletes specific checked notifications from user inbox.
    ACCESS:  Authenticated users
    METHOD:  POST
    """
    guard = require_login()
    if guard: return guard
    notif_ids = []
    if request.is_json:
        payload = request.get_json(silent=True) or {}
        notif_ids = payload.get('ids') or []
    else:
        notif_ids = request.form.getlist('ids') or request.form.getlist('ids[]')
        if not notif_ids and request.form.get('ids_csv'):
            notif_ids = [x.strip() for x in request.form.get('ids_csv', '').split(',') if x.strip()]

    deleted_count = delete_selected_notifications(session['user_id'], notif_ids)
    unread = _get_unread(session['user_id'])
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.is_json:
        return jsonify({'ok': True, 'deleted': deleted_count, 'unread_count': unread})

    if deleted_count > 0:
        flash(f"Deleted {deleted_count} notification(s).", "success")
    else:
        flash("No notifications selected to delete.", "info")
    if session.get('role') == 'student':
        return redirect(url_for('student_timetable', open_notifications='1'))
    return redirect(url_for('notifications_page'))

@app.route("/notifications")
def notifications_page():
    """
    PURPOSE: Inbox view displaying system announcements, schedule updates, and assignment notices.
    ACCESS:  Authenticated users
    METHOD:  GET
    """
    guard = require_login()
    if guard: return guard
    role = session.get('role')
    if role == 'student':
        return redirect(url_for('student_timetable', open_notifications='1'))
    elif role == 'proctor':
        return redirect(url_for('proctor_dashboard', open_notifications='1'))
    elif role == 'secretary':
        return redirect(url_for('secretary_dashboard', open_notifications='1'))
    elif role in ('admin', 'super_admin') or session.get('is_super_admin'):
        return redirect(url_for('dashboard', open_notifications='1'))
    notifs = get_notifications(session['user_id'])
    unread = _get_unread(session['user_id'])
    return render_template("notifications.html",
                           notifications=notifs, unread_count=unread,
                           pending_count=0)

@app.route("/api/notifications/list")
@limiter.exempt
def api_notifications_list():
    """
    PURPOSE: Returns JSON list of notifications and unread count for the active user.
    ACCESS:  Authenticated users
    METHOD:  GET
    """
    uid = session.get('user_id')
    if not uid:
        return jsonify({'expired': True}), 401
    notifs = get_notifications(uid) or []
    unread = _get_unread(uid)
    serialized = []
    for n in notifs:
        serialized.append({
            'id': n.get('id'),
            'title': n.get('title', ''),
            'message': n.get('message', ''),
            'is_read': int(bool(n.get('is_read'))),
            'created_at': str(n.get('created_at', ''))
        })
    resp = jsonify({'unread_count': unread, 'notifications': serialized})
    resp.headers['Cache-Control'] = 'no-store'
    return resp

@app.route("/api/notifications/unread_count")
@limiter.exempt  # polled every ~20s per open tab; must not consume the shared per-IP quota
def api_unread_count():
    """
    PURPOSE: Lightweight polling endpoint for the live notification bell badge.
    ACCESS:  Authenticated users
    METHOD:  GET
    """
    uid = session.get('user_id')
    if not uid:
        return jsonify({'expired': True}), 401
    # Enforce the same 20-minute idle timeout without refreshing _last_active
    last_active = session.get('_last_active')
    if last_active and (time.time() - float(last_active) > 1200):
        return jsonify({'expired': True}), 401
    resp_data = {
        'unread_count': _get_unread(uid),
        'live_signature': get_live_sync_signature()
    }
    # Admin / Super Admin: expose the pending registration queue so open admin pages update live
    if session.get('is_super_admin') or session.get('role') in ('admin', 'super_admin'):
        p_count, p_sig = get_pending_registration_signature()
        resp_data['pending_count'] = p_count
        resp_data['pending_signature'] = p_sig
        resp_data['pending_url'] = '/super_admin' if session.get('is_super_admin') else '/students'
    resp = jsonify(resp_data)
    resp.headers['Cache-Control'] = 'no-store'
    return resp

@app.route("/notifications/mark_read/<int:id>", methods=["POST"])
def mark_read(id):
    """
    PURPOSE: Marks an individual notification as read.
    ACCESS:  Authenticated users
    METHOD:  POST
    """
    guard = require_login()
    if guard: return guard
    mark_notification_read(id, session['user_id'])
    return jsonify({'ok': True})

@app.route("/notifications/mark_all_read", methods=["POST"])
def mark_all_notifs_read():
    """
    PURPOSE: Marks all unread notifications as read for current user.
    ACCESS:  Authenticated users
    METHOD:  POST
    """
    guard = require_login()
    if guard: return guard
    mark_all_read(session['user_id'])
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'ok': True})
    flash("All notifications marked as read.", "success")
    if session.get('role') == 'student':
        return redirect(url_for('student_timetable', open_notifications='1'))
    return redirect(url_for('notifications_page'))

# ==============================================================================
# SECTION 23: USER SELF-SERVICE CREDENTIALS & PROFILE
# ==============================================================================

# ── UNIVERSAL MY ACCOUNT PROFILE & PASSWORD ────────────────────────────────

@app.route("/api/account/me")
def api_account_me():
    """
    PURPOSE: JSON endpoint returning current session profile data for client-side modals.
    ACCESS:  Authenticated users
    METHOD:  GET
    """
    guard = require_login()
    if guard:
        return jsonify({'error': 'Unauthorized'}), 401
    user = get_user_by_id(session['user_id'])
    if not user:
        return jsonify({'error': 'User not found'}), 404
    return jsonify({
        'id': user.get('id'),
        'full_name': user.get('full_name') or session.get('full_name', ''),
        'email': user.get('email') or session.get('email', ''),
        'role': user.get('role') or session.get('role', ''),
        'is_super_admin': bool(user.get('is_super_admin') or session.get('is_super_admin')),
        'section': user.get('section') or '',
        'institute_name': user.get('institute_name') or '',
    })

@app.route("/account/update_profile", methods=["POST"])
def update_my_profile():
    """
    PURPOSE: Self-service endpoint allowing users to update their profile information.
    ACCESS:  Authenticated users
    METHOD:  POST
    """
    guard = require_login()
    if guard: return guard

    role = session.get('role')
    safe_redirects = {
        'proctor': 'proctor_dashboard',
        'student': 'student_timetable',
        'admin': 'dashboard',
        'super_admin': 'super_admin_page',
        'secretary': 'secretary_dashboard',
    }
    fallback = safe_redirects.get(role, 'login')

    def get_redirect():
        ref = request.referrer
        if ref and (request.host in ref):
            return redirect(ref)
        return redirect(url_for(fallback))

    last = request.form.get("last_name", "").strip()
    first = request.form.get("first_name", "").strip()
    middle = request.form.get("middle_name", "").strip()
    suffix = request.form.get("suffix", "").strip()
    if last and first:
        full_name = f"{last}, {first}"
        if middle:
            full_name += f" {middle[0]}." if len(middle) == 1 else f" {middle}"
        if suffix:
            full_name += f" {suffix}"
    else:
        full_name = request.form.get("full_name", "").strip()

    new_email = request.form.get("email", "").strip().lower()
    if not full_name:
        flash("Full name cannot be empty.", "danger")
        return get_redirect()
    if not new_email or not new_email.endswith("@cca.edu.ph"):
        flash("Email must be a valid @cca.edu.ph address.", "danger")
        return get_redirect()

    user_id = session['user_id']
    db = open_db()
    if db:
        try:
            c = db.cursor(dictionary=True)
            c.execute("SELECT id FROM users WHERE LOWER(email) = LOWER(%s) AND id != %s", (new_email, user_id))
            if c.fetchone():
                flash("That email address is already in use by another account.", "danger")
                return get_redirect()

            c.execute("SELECT full_name, email, role, instructor_id FROM users WHERE id = %s", (user_id,))
            curr = c.fetchone()
            if not curr:
                flash("User account not found.", "danger")
                return get_redirect()

            c_w = db.cursor()
            c_w.execute("UPDATE users SET full_name = %s, email = %s WHERE id = %s", (full_name, new_email, user_id))
            if curr.get('role') == 'proctor' and curr.get('instructor_id'):
                c_w.execute("UPDATE instructors SET name = %s WHERE id = %s", (full_name, curr['instructor_id']))
            db.commit()

            session['full_name'] = full_name
            session['email'] = new_email

            log_audit_event('ACCOUNT_PROFILE_UPDATED',
                f"User '{full_name}' ({new_email}, role: {curr.get('role')}) updated their account profile.",
                user_id=user_id,
                user_name=full_name,
                user_role=curr.get('role'),
                ip_address=request.remote_addr
            )
            flash("Your account profile has been updated successfully.", "success")
        except Exception as e:
            flash("An error occurred while updating account profile.", "danger")
        finally:
            db.close()
    return get_redirect()

@app.route("/change_my_password", methods=["POST"])
def change_my_password():
    """
    PURPOSE: Self-service password change verifying current password before hashing and saving new password.
    ACCESS:  Authenticated users
    METHOD:  POST
    """
    guard = require_login()
    if guard: return guard
    role = session.get('role')
    redirect_to = request.form.get("redirect_to", "")
    safe_redirects = {
        'proctor': 'proctor_dashboard',
        'student': 'student_timetable',
        'admin': 'dashboard',
        'super_admin': 'super_admin_page',
        'secretary': 'secretary_dashboard',
    }
    fallback = safe_redirects.get(role, 'login')

    def get_redirect():
        ref = request.referrer
        if ref and (request.host in ref):
            return redirect(ref)
        target = redirect_to if redirect_to in safe_redirects.values() else fallback
        return redirect(url_for(target))

    current_password = request.form.get("current_password", "").strip()
    new_password     = request.form.get("new_password", "").strip()
    confirm_password = request.form.get("confirm_password", "").strip()

    if not current_password or not new_password or not confirm_password:
        flash("All password fields are required.", "danger")
        return get_redirect()
    is_valid, err_msg = validate_password_strength(new_password)
    if not is_valid:
        flash(err_msg, "danger")
        return get_redirect()
    if new_password != confirm_password:
        flash("New passwords do not match.", "danger")
        return get_redirect()
    if new_password == current_password:
        flash("New password cannot be the same as your current password.", "warning")
        return get_redirect()

    db = open_db()
    if db:
        try:
            import bcrypt as _bcrypt
            c_db = db.cursor(dictionary=True)
            c_db.execute("SELECT id, password FROM users WHERE id = %s", (session['user_id'],))
            user = c_db.fetchone()
            if not user:
                flash("User account not found.", "danger")
                return get_redirect()

            stored_pw = user.get('password') or ''
            try:
                current_ok = _bcrypt.checkpw(current_password.encode(), stored_pw.encode())
            except (ValueError, TypeError, Exception):
                current_ok = False

            if not current_ok:
                flash("Current password is incorrect.", "danger")
                return get_redirect()

            hashed = _bcrypt.hashpw(new_password.encode(), _bcrypt.gensalt()).decode()
            c_db.execute("UPDATE users SET password = %s WHERE id = %s", (hashed, session['user_id']))
            db.commit()
            flash("Password updated successfully.", "success")
        except Exception as e:
            flash(f"Error updating password: {e}", "danger")
        finally:
            db.close()
    return get_redirect()


@app.route("/admin/batch_print_sections")
def admin_batch_print_sections():
    """
    PURPOSE: Batch examination pass and schedule sheet generator for an entire academic section.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    
    all_exams = get_schedule_results()
    scheduled = [e for e in all_exams if e['status'] == 'Scheduled']
    
    # Group by section
    sections_dict = defaultdict(list)
    for exam in scheduled:
        sec = exam.get('section', '').strip()
        if sec:
            sections_dict[sec].append(exam)
            
    dates_set = set()
    times_set = set()
    sec_exams_by_start = defaultdict(lambda: defaultdict(list))
    
    for sec, exams in sections_dict.items():
        for exam in exams:
            dt = exam['exam_date_time']
            if isinstance(dt, str):
                dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
            d_str = dt.strftime("%Y-%m-%d")
            t_str = dt.strftime("%H:%M")
            exam['_date_label'] = dt.strftime("%a %b %d")
            exam['datetime_raw'] = dt.strftime("%Y-%m-%dT%H:%M")
            dur = int(exam.get('duration_minutes') or 60)
            end_dt = dt + timedelta(minutes=dur)
            exam['duration_minutes'] = dur
            exam['time'] = dt.strftime("%I:%M %p")
            exam['time_end'] = end_dt.strftime("%I:%M %p")
            exam['time_range'] = f"{exam['time']} - {exam['time_end']}"
            
            sec_exams_by_start[sec][(t_str, d_str)].append(exam)
            dates_set.add(d_str)
            times_set.add(t_str)
            
            # For multi-hour exams, ensure each hourly slot is in times_set
            extra_hours = int((dur - 1) // 60)
            for h in range(1, extra_hours + 1):
                cont_dt = dt + timedelta(hours=h)
                times_set.add(cont_dt.strftime("%H:%M"))
        
    dates_list = sorted(list(dates_set))
    times_list = sorted(list(times_set))
    
    date_labels = {}
    time_labels = {}
    for sec, exams in sections_dict.items():
        for e in exams:
            if '_date_label' in e:
                dt = e['exam_date_time']
                if isinstance(dt, str):
                    dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
                date_labels[dt.strftime("%Y-%m-%d")] = e['_date_label']
                if 'time' in e:
                    time_labels[dt.strftime("%H:%M")] = e['time']

    for t_str in times_list:
        try:
            start_obj = datetime.strptime(t_str, "%H:%M")
            end_obj = start_obj + timedelta(hours=1)
            time_start_str = start_obj.strftime("%I:%M %p")
            time_end_str = end_obj.strftime("%I:%M %p")
            time_labels[t_str] = f"{time_start_str} - {time_end_str}"
        except Exception:
            time_labels[t_str] = t_str

    # Build merged-cell table rows with rowspan for each section
    section_tables = {}
    for sec, exams_map in sec_exams_by_start.items():
        active_spans = {d: 0 for d in dates_list}
        rows = []
        for t_idx, t in enumerate(times_list):
            try:
                start_obj = datetime.strptime(t, "%H:%M")
                end_obj = start_obj + timedelta(hours=1)
                t_start = start_obj.strftime("%I:%M %p")
                t_end = end_obj.strftime("%I:%M %p")
            except Exception:
                t_start = t
                t_end = ""
            row_cells = []
            for d in dates_list:
                if active_spans[d] > 0:
                    row_cells.append({'is_skipped': True, 'date': d})
                    active_spans[d] -= 1
                else:
                    cell_exams = exams_map.get((t, d), [])
                    if cell_exams:
                        max_dur = max(int(e.get('duration_minutes') or 60) for e in cell_exams)
                        start_dt = datetime.strptime(t, "%H:%M")
                        end_dt = start_dt + timedelta(minutes=max_dur)
                        span = 0
                        for check_t in times_list[t_idx:]:
                            c_dt = datetime.strptime(check_t, "%H:%M")
                            if c_dt < end_dt:
                                span += 1
                            else:
                                break
                        span = max(span, 1)
                        if span > 1:
                            active_spans[d] = span - 1
                        row_cells.append({
                            'is_skipped': False,
                            'rowspan': span,
                            'exams': cell_exams,
                            'date': d
                        })
                    else:
                        row_cells.append({
                            'is_skipped': False,
                            'rowspan': 1,
                            'exams': [],
                            'date': d
                        })
            rows.append({
                'time_str': t,
                'time_start': t_start,
                'time_end': t_end,
                'time_label': time_labels.get(t, t),
                'cells': row_cells
            })
        section_tables[sec] = rows
                
    return render_template("batch_print.html",
                           time_labels=time_labels,
                           section_tables=section_tables,
                           dates=dates_list,
                           times=times_list,
                           date_labels=date_labels,
                           exam_term=get_exam_term()[0],
                           exam_semester=get_exam_term()[1])

@app.route("/admin/print_section")
def admin_print_section():
    """
    PURPOSE: Renders printable exam pass and schedule slip for a specific section.
    ACCESS:  Admin, Super Admin
    METHOD:  GET
    """
    guard = require_role('admin')
    if guard: return guard
    section = request.args.get('section', '').strip()
    if not section:
        flash("Please select a section.", "error")
        return redirect(url_for('schedule_view'))
    
    exams = get_public_timetable(section=section, bypass_published_guard=True)
    grouped = defaultdict(list)
    for exam in exams:
        dt = exam['exam_date_time']
        if not dt: continue
        if isinstance(dt, str):
            dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
        exam['time']     = dt.strftime("%I:%M %p")
        exam['time_end'] = (dt + timedelta(minutes=int(exam['duration_minutes'] or 60))).strftime("%I:%M %p")
        grouped[dt.strftime("%A, %B %d, %Y")].append(exam)
    
    sorted_groups = sorted(grouped.items(), key=lambda x: datetime.strptime(x[0], "%A, %B %d, %Y"))
    
    return render_template("student_timetable.html",
                           grouped=sorted_groups,
                           total=len(exams),
                           section=section,
                           full_name="Admin Generated",
                           institute_name="City College of Angeles",
                           exam_term=get_exam_term()[0],
                           exam_semester=get_exam_term()[1])

@app.route("/timetable")
@app.route("/student/timetable")
def student_timetable():
    """
    PURPOSE: Personalized student portal displaying registered exam schedule, rooms, and proctor assignments.
    ACCESS:  Student
    METHOD:  GET
    """
    guard = require_role('student')
    if guard: return guard
    # Synchronize official section and institute from database
    db_sync = open_db()
    if db_sync:
        try:
            c_sync = db_sync.cursor(dictionary=True)
            c_sync.execute('SELECT section, institute_id FROM users WHERE id = %s', (session['user_id'],))
            u_row = c_sync.fetchone()
            if u_row:
                session['section'] = u_row.get('section') or ''
                if u_row.get('institute_id'):
                    session['institute_id'] = u_row['institute_id']
        except Exception:
            pass
        finally:
            db_sync.close()
    is_pub = is_schedule_published()
    section      = session.get('section', '')
    institute_id = session.get('institute_id')
    full_name    = session.get('full_name', 'Student')
    if not is_pub:
        exams = []
        sorted_groups = []
    else:
        exams = get_public_timetable(section=section)
        grouped = defaultdict(list)
        for exam in exams:
            dt = exam['exam_date_time']
            if not dt: continue
            if isinstance(dt, str):
                dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
            exam['time']     = dt.strftime("%I:%M %p")
            exam['time_end'] = (dt + timedelta(minutes=int(exam['duration_minutes'] or 60))).strftime("%I:%M %p")
            grouped[dt.strftime("%A, %B %d, %Y")].append(exam)
        sorted_groups = sorted(grouped.items(),
                               key=lambda x: datetime.strptime(x[0], "%A, %B %d, %Y"))
    # Get institute name
    institute_name = ''
    if institute_id:
        all_inst = get_all_institutes()
        for i in all_inst:
            if i['id'] == institute_id:
                institute_name = i['name']
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    unread = _get_unread(session['user_id'])
    student_notifs = get_notifications(session['user_id'])
    
    db_conn = open_db()
    available_sections = []
    if db_conn:
        try:
            cur = db_conn.cursor()
            cur.execute("SELECT DISTINCT section FROM (SELECT section FROM users WHERE section IS NOT NULL AND section != '' UNION SELECT section FROM exams WHERE section IS NOT NULL AND section != '') AS s ORDER BY section")
            available_sections = [r[0] for r in cur.fetchall()]
        finally:
            db_conn.close()

    return render_template("student_timetable.html",
                           grouped=sorted_groups,
                           total=len(exams),
                           section=section,
                           full_name=full_name,
                           institute_name=institute_name,
                           exam_term=exam_term,
                           exam_semester=exam_semester,
                           unread_count=unread,
                           notifications=student_notifs,
                           is_published=is_pub,
                           available_sections=available_sections)

@app.route("/student/schedule.pdf")
def export_student_schedule_pdf_route():
    """
    PURPOSE: Generates official printable student exam pass PDF with timetable and seat requirements.
    ACCESS:  Student
    METHOD:  GET
    """
    guard = require_role('student')
    if guard: return guard
    if not is_schedule_published():
        flash("The official examination timetable is currently in Draft mode under administrative review. Examination permits cannot be downloaded yet.", "warning")
        return redirect(url_for('student_timetable'))
    section      = session.get('section', '')
    institute_id = session.get('institute_id')
    full_name    = session.get('full_name', 'Student')
    exams = get_public_timetable(section=section)
    term_tuple = get_exam_term()
    exam_term = term_tuple[0] if term_tuple and term_tuple[0] else 'Midterm'
    exam_semester = term_tuple[1] if term_tuple and len(term_tuple) > 1 and term_tuple[1] else '1st Semester'
    
    from system.exporter import export_student_permit_pdf
    pdf_bytes = export_student_permit_pdf(
        student_name=full_name,
        section=section,
        exams=exams,
        exam_term=exam_term,
        exam_semester=exam_semester
    )
    
    import re
    safe_sec = re.sub(r'[^a-zA-Z0-9]+', '_', section).strip('_').lower() if section else 'student'
    filename = f"exam_permit_{safe_sec}.pdf"
    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype='application/pdf',
        as_attachment=False,
        download_name=filename
    )

@app.route("/student/update_section", methods=["POST"])
def student_update_section():
    """
    PURPOSE: Allows student to correct or update their section assignment.
    ACCESS:  Student
    METHOD:  POST
    """
    guard = require_role('student')
    if guard: return guard

    new_section = request.form.get("section", "").strip()
    log_audit_event('UNAUTHORIZED_SECTION_EDIT_ATTEMPT',
        f"Student {session.get('full_name')} (ID #{session.get('user_id')}) attempted an unauthorized self-service section modification to '{new_section}'.",
        user_id=session.get('user_id'),
        user_name=session.get('full_name'),
        user_role='student',
        ip_address=request.remote_addr
    )
    flash("The official examination timetable and class sections are locked down. Section modifications are locked. Students cannot self-modify class sections. Please contact your Department Administrator or Academic Head to request an official change.", "warning")
    return redirect(url_for('student_timetable'))

# ==============================================================================
# SECTION 24: MISCELLANEOUS & DEBUG UTILITIES
# ==============================================================================

@app.route("/clear-session")
def clear_session():
    """
    PURPOSE: Debug endpoint to reset local session during development.
    ACCESS:  Debug / Admin
    METHOD:  GET
    """
    session.clear()
    response = redirect(url_for('index'))
    response.delete_cookie('session')
    return response

# ==============================================================================
# SECTION 25: APPLICATION SERVER ENTRYPOINT
# ==============================================================================

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 9999))
    host = os.environ.get("HOST", "127.0.0.1")
    app.run(debug=True, host=host, port=port)









